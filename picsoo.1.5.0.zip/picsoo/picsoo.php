<?php

/**
 * Exports data to Picsoo
 *
 * @package   	Picsoo
 * @author		Dominique HUGO (info@ciel-software.be)
 * @copyright	Copyright 2023-2024 (c) Picsoo.eu
 * @version		1.5.0		
 */
 
if (!defined('_PS_VERSION_') || !defined('_CAN_LOAD_FILES_'))
	exit;
// Set to true if you want to debug the Export framework in the test sandbox
define ('PS_PICSOO_DEBUG', false);

// plugin version
define ('PS_PICSOO_MODULE_VERSION', '1.5.0');

include_once(dirname(__FILE__).'/libs/Picsoo_ws.php') ;

class Struct_XImport
{
    public $_MVTS; // N° Mouvement
    public $_ID; // Identification dans la base des sma_sales
    public $_JOUR; // Code journal
    public $_DECR; // Date écriture
    public $_DECH; // Date échéance
    public $_NUMP; // N° de pièce
    public $_COMP; // N° de compte
    public $_LIBE; // Libellé écriture
    public $_MONT; // Montant
    public $_SENS; // Sens montant
    public $_LETT; // Ref. pointage / lettrage
    public $_ANAL; // Code analytique
    public $_MTVA; // Montant TVA
    public $_TTVA; // Taux de TVA
    public $_CTVA; // Code TVA
	public $_GTVA; // grille TVA
	public $_GBAS; // grille Base
    //DateTime _DARE; // Date réelle
    //string _QUI1; // 
}

class Struct_BadTrans
{
	public $_MVTS;
	public $_ID;
	public $_DEBIT;
	public $_CREDIT;
}

class Picsoo extends Module 
{
	protected $token;
	private $objCustomerExcel;
	private $objPicsooWS;
	private $current_email;

	private $clientsid;
	public $clientsid_list;
	private $vatlist; // liste des paramètres de tva pour le client sélectionné
	private $ximportslist; // liste des données comptables
	private $genmsg; // message général

	private $ie_clientsid;
	private $ie_category;
	private $ie_startdate;
	private $ie_enddate;
	private $ie_reference;
	private $ie_updexisting;
	private $ie_incifbadimage;
	private $ie_typetft;
	private $ie_datatft;
	//private $ie_mytype;
	//private $ie_status;
	private $ie_tft_articles;
	private $ie_tft_clients;
	private $ie_tft_fournisseurs;
	private $ie_tft_transactions;

	private $reference_external;
	private $toexcel;

	private $WSinitialized;

	private $log_message;
	private $ErrNumber;

	private $count_total;
	private $count_transfered;

	public function __construct()
	{
		$this->name = 'picsoo';
		$this->tab = 'administration';
		$this->version = '1.5.0';
		$this->author = 'Picsoo.eu';
		$this->need_instance = 0;
		$this->bootstrap = true;
		// Visible name shown on Modules tab in the Back Office.
		$this->displayName = $this->l('Picsoo');
		// Describe shortly your module here.
		$this->description = $this->l('Picsoo import/export module.');
		// This should display when user tries to uninstall the module.
		$this->confirmUninstall = $this->l('Are you sure you want to remove all your settings?');
		//        $this->configs = unserialize(configuration::get('EXPORT_FIELD'));
		//        $this->data = unserialize(configuration::get('CONFIG_DATA'));

		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);

		//specific settings or variable

		parent::__construct();

		$this->token = Tools::getAdminToken('picsooio');
		$this->WSinitialized = false;

		$this->reference_external = 'PRESTA_xxxxxxxxx';
	}

	public function install()
	{
		if (Shop::isFeatureActive())
		{
			Shop::setContext(Shop::CONTEXT_ALL);
		}
		return parent::install() && $this->registerHook('backOfficeHeader');
	}

	public function uninstall()
	{
        return parent::uninstall();
	}

	public function hookBackOfficeHeader()
	{
		$this->context->controller->addJquery();
		$this->context->controller->addJS($this->_path.'views/js/back.js');
	}

	public function getContent()
	{
		//return $this->displayConfirmation($this->trans('The settings have been updated.', [], 'Admin.Notifications.Success'));

		if ( $this->WSinitialized == false )
		{
			$this->InitPicsooWS();
			$this->WSinitialized = true;
		}

		$output = null;
		$content = '';
		$errmsg = '';

		if ( Tools::isSubmit('submitForm2') )
		{
			//$my_module_name = strval(Tools::getValue('MYMODULE_PRESTA'));
			//$my_category = strval(Tools::getValue('category'));
			//$my_picsoo_company = strval(Tools::getValue('picsoo_company'));
/*if (!$my_module_name || empty($my_module_name) || !Validate::isGenericName($my_module_name))
$output .= $this->displayError($this->l('Invalid Configuration value'));
else
{
Configuration::updateValue('MYMODULE_PRESTA', $my_module_name);
$output .= $this->displayConfirmation($this->l('Settings updated'));
}
Configuration::updateValue('MYMODULE_PRESTA1', Tools::getValue('MYMODULE_PRESTA1'));*/
			//Configuration::updateValue('density', Tools::getValue('density'));

			$var = $this->clientsid_list[strval(Tools::getValue('picsoo_company'))];
			$this->ie_clientsid = strtok($var,' ');
			if ( $this->ie_datatft != 4 ) // export to excel, we don't care about the company
			{
				if ( $this->ie_clientsid == null )
					$errmsg = 'La société sélectionnée est incorrecte.';
			}
			//$this->ie_clientsid = '10888'; // DEBUG
			//$this->session->set_flashdata('message', '$this->ie_clientsid');
			$this->ie_category = strval(Tools::getValue('category'));
			$this->ie_startdate = strval(Tools::getValue('start_date'));
			$this->ie_enddate = strval(Tools::getValue('end_date'));
			$this->ie_reference = $this->reference_external;
			if( Tools::getValue('name_upd_existing')=='1' )
				$this->ie_updexisting = true;
			else
				$this->ie_updexisting = false;
			if( Tools::getValue('name_incifbadimage')=='1' )
				$this->ie_incifbadimage = true;
			else
				$this->ie_incifbadimage = false;
			$this->ie_typetft = strval(Tools::getValue('typetft')); // 0 = importer 1 = exporter
			$this->ie_datatft = strval(Tools::getValue('tft_data'));

			if ($this->ie_datatft == null )
				// necessary only in case of checkboxes
			$errmsg = 'Veuillez choisir au moins un élément à transférer.';

			if ( $errmsg != '' )
			{
				$content .= $this->displayError($errmsg, [], 'Modules.Crossselling.Admin');
			}
			else
			{
				$err = $this->ProcessDispatcher();

				if ( $this->ie_typetft == 0 /*0:import 1:export*/ )
				{
					$msg = 'Import terminé';
					if ( $this->ErrNumber != 0 )
					{
						$msg .= ' ( des erreurs ont été détectées )';
						$msg .= '<br>';
						$msg .= $this->genmsg;
						$content .= $this->displayError($msg);
					}
					else
					{
						$msg .= '<br>';
						$msg .= $this->genmsg;
						$msg .= ' (' . $this->count_transfered . '/' . $this->count_total . ')';
						$content .= $this->displayConfirmation( $msg );
						//$content .= $this->displayConfirmation($this->trans( $msg, [], 'Admin.Notifications.Success'));
						//$content .= $this->displayConfirmation($this->trans( $this->genmsg, [], 'Admin.Notifications.Success'));
					}
				}
				else
					// export
				{
					$msg = 'Export terminé';
					if ( $this->ErrNumber != 0 )
					{
						$msg .= ' ( des erreurs ont été détectées )';
						$msg .= '<br>';
						$msg .= $this->genmsg;
						$content .= $this->displayError($msg);
						//$content .= $this->displayError($this->genmsg, [], 'Modules.Crossselling.Admin');
					}
					else
					{
						$msg .= '<br>';
						$msg .= $this->genmsg;
						$content .= $this->displayConfirmation( $msg );
						//$content .= $this->displayConfirmation($this->trans( $this->genmsg, [], 'Admin.Notifications.Success'));
					}
				}
			}
		}

		if ( $this->objPicsooWS->IsStaging() )
			$content .= $this->displayError("Version Staging !");
			//$content .= $this->displayConfirmation($this->trans( "Version Staging", [], 'Admin.Notifications.Success'));

		$content .= $this->context->smarty->fetch($this->local_path . 'views/templates/admin/header.tpl');
		$content .= $this->renderForm();
		//$content .= $this->displayParamGeneral();
		//$content .= $this->displayTypeTransfert();
		//$content .= $this->displayTypeDeDonnees();
		$content .= $this->context->smarty->fetch($this->local_path . 'views/templates/admin/footer.tpl');
		return $content;
	}

	// -------------------------------------------------------------------------------------------------------------------------------------------------------
	// https://www.prestashop.com/forums/topic/613783-2-forms-on-the-same-module/
	public function renderForm()
	{
		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitModule';
		$helper->module = $this;
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->fields_value = array(
		'name_incifbadimage' => true,
		'name_upd_existing' => false,
		'reference_no' => $this->reference_external,
		'start_date' => date('Y-m-d', strtotime(' - 1 months')) /*date('Y-m-d')*/ ,
		'end_date' => date('Y-m-d'),
		'typetft' => 0, // 0 = importer -- 1 = exporter
		);

		return $helper->generateForm( array( $this->GetParamGeneral(), $this->GetTypeTransfert(), $this->GetTypeData() ));
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	public function GetParamGeneral()
	{
		// Get default language
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

		$idclientslist = array();
		foreach ( $this->clientsid_list as $key => $value )
		{
			$idclientslist[] = array( "id_company_name" => (int)$key, "name" => $value );
		}

		$fields_form_1 = array(
		'form' => array(
		'legend' => array( 'title' => $this->l('Paramétrage général') . ' 11', 'icon' => 'icon-cogs' ),
		'input' => array(

		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		// Picsoo company --------------------------------------------------------------------------------------------
		array( 'type' => 'select',
			'label' => $this->l('Société Picsoo'),
			'name' => 'picsoo_company',
			'width' => '200',
			'options' => array( 'query' =>  $idclientslist,
			'id' => 'id_company_name',
			'name' => 'name' ),
			'class' =>  'fixed-width-xxl'
		),

		// catégorie par défaut ----------------------------------------------------------------------------------------
		array( 'type' => 'text',
			'label' => $this->l('Catégorie (articles) par défaut si non renseignée dans Picsoo: '),
			'name' => 'category',
			'size' => 20,
			'required' => true
		),

		// Dates de début / fin ----------------------------------------------------------------------------------------
		/*array( 'type' => 'date',
			'label' => $this->trans('From', array(), 'Admin.Global'),
			'name' => 'start_date',
			'maxlength' => 10,
			'required' => true,
			'hint' => $this->trans('Format: 2011-12-31 (inclusive).')
		),
		array( 'type' => 'date',
			'label' => $this->trans('To', array(), 'Admin.Global'),
			'name' => 'end_date',
			'maxlength' => 10,
			'required' => true,
			'hint' => $this->trans('Format: 2012-12-31 (inclusive).' )
		),*/

		// reference external ------------------------------------------------------------------------------------------
		array( 'type' => 'text',
			'label' => $this->l('Référence pour Picsoo (export uniquement)'),
			'name' => 'reference_no',
			'size' => 20,
			'required' => true,
			'disabled' => true,
			'value' => 'PRESTA_xxxxxxxxx'
		),

		// Inclure les articles si image non supportée ----------------------------------------------------------------
        array(
            'type' => 'checkbox',
            'label' => $this->l("Inclure les articles contenant des images au format non supporté (Prestashop n'accepte que les jpg et png)"),
            'name' => 'name',
            'values' => array(
                'query' => array(
                    array(
                        'id' => 'incifbadimage',
                        'val' => 1, // NE PAS MODIFIER !
                    ),
                ),
                'id' => 'id',
            ),
        ),
		// Mise-àjour de l'élément si existant -------------------------------------------------------------------------
        // + tard
		/*array(
            'type' => 'checkbox',
            'label' => $this->l('Mise-à-jour de l\'élément si existant (uniquement articles, clients)'),
            'name' => 'name',
            'values' => array(
                'query' => array(
                    array(
                        'id' => 'upd_existing',
                        'val' => 1, // NE PAS MODIFIER !
                    ),
                ),
                'id' => 'id',
            ),
        ),*/
		// EN OPTION : On peut cacher les champs ici avec un bouton plus ou moins
		//   'expand' => array(
		//         ['print_total'] => count($option),
		//         'default' => 'show',
		//         'show' => array('text' => $this->l('show'), 'icon' => 'plus-sign-alt'),
		//         'hide' => array('text' => $this->l('hide'), 'icon' => 'minus-sign-alt'),
		//   ),

		// -------------------------------------------------------------------------------------------------------------------------------------------------------
		// switch OK

		/*array(
			'type' => 'switch',
			'label' => $this->l('Enabled'),
			'name' => 'active_slide',
			'is_bool' => true,
			'values' => array(
				array(
					'id' => 'active_on',
					'value' => 1,
					'label' => $this->l('Yes')
				),
				array(
					'id' => 'active_off',
					'value' => 0,
					'label' => $this->l('No')
				)
			),
		),*/

		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		) // end of input
		),
		);

		return $fields_form_1;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	public function GetTypeTransfert()
	{
		// Get default language
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');


		$fields_form_1 = array( 'form' => array( 'legend' => array( 'title' => $this->l('Type de transfert'), 'icon' => 'icon-cogs' ),
		'input' => array(

		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		// EN OPTION : On peut cacher les champs ici avec un bouton plus ou moins
		//   'expand' => array(
		//         ['print_total'] => count($option),
		//         'default' => 'show',
		//         'show' => array('text' => $this->l('show'), 'icon' => 'plus-sign-alt'),
		//         'hide' => array('text' => $this->l('hide'), 'icon' => 'minus-sign-alt'),
		//   ),

		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		// radio Importer / Exporter ----------------------------------------------------------------------------------

		array( 'type' => 'radio',
		'label' => $this->l('Type'),
		'name' => 'typetft',
		'class' => 't',
		'required'  => true,
		'disabled' => false,
		'is_bool' => true,
		'values' => array( array( 'id' => 'import', 'value' => 0, 'label' => $this->l('Importer') ),
		array( 'id' => 'export', 'value' => 1, 'label' => $this->l('Exporter') )
		),
		)

		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		) // end of input
		//'submit' => array(
		//'title' => $this->l('Save'),
		//'class' => 'btn btn-default pull-right',
		//'name' => 'submitForm1',
		//)
		),
		);

		return $fields_form_1;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	public function GetTypeData()
	{
		$fields_form_1 = array( 'form' => array( 'legend' => array( 'title' => $this->l('Type de données à transférer (un seul type n\'est possible à la fois pour des raisons d\'optimalité)'),
		'icon' => 'icon-cogs'
		),
		'input' => array(

		// -------------------------------------------------------------------------------------------------------------------------------------------------------

		// radio Importer / Exporter ----------------------------------------------------------------------------------

		array( 'type' => 'radio', 'label' => $this->l('Type'), 'name' => 'tft_data', 'class' => 't', 'required'  => true, 'is_bool' => true, 'values' =>
		array(
		array( 'id' => 'products', 'value' => 0, 'label' => $this->l('Articles') ),
		array( 'id' => 'customers', 'value' => 1, 'label' => $this->l('Clients (en export, seuls les clients utilisés dans les ventes seront exportés)') )
		//array( 'id' => 'suppliers', 'value' => 2, 'label' => $this->l('Fournisseurs') ),
		//array( 'id' => 'orders_to_picsoo', 'value' => 3, 'label' => $this->l('Données comptables (export uniquement: le transfert se fera de PRESTASHOP vers Picsoo web (il faut, au préalable, avoir transféré les clients !)'), 'disabled' => false ),
		//array( 'id' => 'orders_to_file', 'value' => 4, 'label' => $this->l('Générer un fichier comptable au format excel (aucune données ne sera transférée vers Picsoo web)'), 'disabled' => false )
		),
		),

		// -------------------------------------------------------------------------------------------------------------------------------------------------------
		), // end input
		// -- bouton de lancement du process ---------------------------------------------------------------------------------------------------------------------
		'submit' => array( 'title' => $this->l('Execute'), 'class' => 'btn btn-default pull-right', 'name' => 'submitForm2', ) ),
		);

		return $fields_form_1;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function InitPicsooWS()
	{
		//$employee = $this->context->employee;
		//$this->current_email = $employee->email;

		$this->objPicsooWS = new Picsoo_ws();
		$this->current_email = $this->objPicsooWS->PicsooEMail();
		
		if ( $this->objPicsooWS->IsDemoVersion() && $this->objPicsooWS->IsStaging() )
			$currentemail = 'demotic@gmail.com';
		else
			$currentemail = $this->current_email;

		$psw = "";
		
		$this->clientsid = $this->objPicsooWS->GetCompaniesListByEmail( $currentemail ); // juste la liste associée à l'email
		
		foreach ($this->clientsid as $key => $value )
		{
			$var1 = $key;
			$var2 = $value;
			//$clt[] = array_combine($key, $value);
			//$clt[] = array_combine($value['clients_id'], $value['clients_id']." ".$value['organisation_name']);
			$this->clientsid_list[ $key ] = $value['clients_id']." ".$value['organisation_name'];
			//echo $clients_id['clients_id']." ".$clients_id['organisation_name']."<br>";
		}
		
		$this->objPicsooWS->SetUsernamePsw( $currentemail, $psw );
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessDispatcher()
	{
		//$this->adminDisplayWarning('Test test');
		//$this->adminDisplayInformation('Test test');

		$this->ErrNumber = 0;

		//unlink("json_transactions_log.txt"); //DBG
		//unlink("result_transactions_log.txt"); //DBG

		// import
		if ( $this->ie_typetft == 0 /*'import'*/ )
		{
			if ($this->ie_datatft == 0)
			// articles
			$err = $this->ProcessImportArticles();
			if ($this->ie_datatft == 1)
			// clients
			$err = $this->ProcessImportCompanies('C');
			if ($this->ie_datatft == 2)
			// fournisseurs
			$err = $this->ProcessImportCompanies('S');
		}
		else
			// export
		{
			if ($this->ie_datatft == 0)
				$err = $this->ProcessExportArticles(); // articles
			if ($this->ie_datatft == 1)
				$err = $this->ProcessExportCompanies('C'); // clients
			//if ($this->ie_datatft == 2)
			//$err = $this->ProcessExportCompanies('S'); // fournisseurs
				if ($this->ie_datatft == 3)
				$err = $this->ProcessExportTransactions(); // transactions
			if ($this->ie_datatft == 4)
			{
				$this->toexcel = true;
				$err = $this->ProcessExportTransactions(); // transactions > excel
			}
		}

		return $err;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessImportArticles()
	{
		$cnt = 0;
		$err = 0;
		$picsooitemname = '';
		$this->count_total = 0;
		$this->count_transfered = 0;
		
		/*$dbg = $this->ValidateName("Extension 114 mm 5/8''\r\nExtension longueur 114 mm, avec filet 5/8 femelle et 5/8 mâle aux extrêmités.\r\n• Ø 25 mm\r\n��");
		$product = new Product();
		$product->ean13 = 9999999999999;
		$product->name = array((int)Configuration::get('PS_LANG_DEFAULT') =>  $dbg );
		$product->link_rewrite = ''; //array((int)Configuration::get('PS_LANG_DEFAULT') =>  "Mini prisme sous boîtier MP24; diamètre 25 mm; précision 2'' pour support support de prisme type ONRT 50  - Portée possib" );
		$product->id_category = 2;
		$product->id_category_default = 2;
		$product->redirect_type = '404';
		$product->price = 22;
		$product->quantity = 1;
		$product->minimal_quantity = 1;
		$product->show_price = 1;
		$product->on_sale = 0;
		$product->online_only = 1;
		$product->meta_keywords = 'test';
		$product->is_virtual=1;
		$product->add();
		return;*/

		$typearticle = 'standard';
		$category_code = $this->ie_category;
		//$category_name = $this->getCategoryByCode($category_code);
		//$category_name = $this->site->getCategoryByID($category_code);

		$itemslist = $this->objPicsooWS->GetItemsList($this->ie_clientsid);
		$this->count_total = count($itemslist);

		//$titles  = array_shift($arrResult);
		$updated = 0;
		$items   = [];

		foreach ($itemslist as $picsooitem)
		{
			if ( $picsooitem['is_deleted'] == true )
				continue;

			//$dbg = $picsooitem['item_name'];
			if( !isset($picsooitem['item_name']) )
				continue;

			//if( $picsooitem['item_name'] != 'BO0297.100' ) // BMP
			//		continue;
			//if( $picsooitem['item_name'] != 'SE2090-06' ) // JPG
			//	continue;
			
			$picsooitemname = '';
			/*if( isset($picsooitem['FRItemDescription']) )
			{
				if( $picsooitem['FRItemDescription'] != '' )
					$picsooitemname = $picsooitem['FRItemDescription'];
				else if( isset($picsooitem['item_nomianlcode']) )
				{
					$picsooitemname = $picsooitem['item_nomianlcode'];
				}
				else
					$picsooitemname = '';
			}*/
			if( isset($picsooitem['item_nomianlcode']) )
				$picsooitemname = $picsooitem['item_nomianlcode'];
			
			//if( $cnt>=1 )
			//	break;
			//if( $picsooitemname != 'LOGICIEL HAPPY RTK + HAPPY RTR (Gestion GNSS et Robotique) - Android software' ) // HAPPY MAINTENANCE RTK SURVEY (GNSS)
			//	continue;

			//$dbg = $this->ValidateName(substr(trim($picsooitem['item_description']),0,125));
/* DH DEBUG */
			//$myfile = fopen("items_log.txt", "a") or die("Unable to open file!");
			//$results = print_r($picsooitem['item_name']."\n", true); // $results now contains output from print_r
			//fwrite($myfile, $results /*serialize($datatosend)*/);
			//fclose($myfile);

			$supplier_name = $picsooitem['Fksupplierid'];
			//$supplier_name = $picsooitem['suppliercode']; // à voir lequel des 2

			$supplier      = ''; //$supplier_name ? $this->getSupplierByName($supplier_name) : false;
			//$category_name = $this->objPicsooWS->GetCategoryName($this->ie_clientsid, '1891');
			//$category_name = $picsooitem['name'];
			//$category_id = $picsooitem['fk_category_id'];

			// si pas de catégorie dans Picsoo, on prend le défaut choisi par l'utilisateur
			/*if ( $category_name == '' )
			{
				$var = $this->getCategoryById( $this->ie_category);
				$category_name = $var->name;
				$category_id = $var->id;
			}*/

			// l'image du product
			$tmppic = '';
			$dataimg = $this->objPicsooWS->GetItemImage( $this->ie_clientsid,  $picsooitem['item_id']);
			if( $dataimg['IsSuccess']=="true" )
			{
				$datapic = $dataimg['Data'];
				if( !$this->objPicsooWS->IsNullOrEmptyString($datapic['File']))
				{
					$imgtypep = $datapic['FileType']; //  "JPEG", "PNG", "BMP", "GIF", "TIFF", "Unknown"
			        $tmppic = ''; 

					if( $imgtypep=="JPEG" || $imgtypep=="PNG") 
					{
						$imgname = $picsooitem['item_name'] . '.tmp' /*$datapic['FileExtension']*/;
						$tmppic = tempnam(_PS_TMP_IMG_DIR_, 'ps_import');
						$this->objPicsooWS->save_image_from_buffer( $datapic['File'], $tmppic );
						/*$imgtype = getimagesize($tmppic); // php version
						switch ($imgtype['mime']) 
						{ 
						    case "image/gif": 
								unlink( $tmppic );
						        $tmppic = ''; 
						        break; 
						    case "image/jpeg": 
						        break; 
						    case "image/png": 
						        break; 
						    case "image/bmp": 
								unlink( $tmppic );
						        $tmppic = ''; 
						        break; 
						}*/
					}
					else
					{
					}

				if( $this->objPicsooWS->IsNullOrEmptyString($tmppic) && !$this->ie_incifbadimage )
					continue;
				}
			}
			
			if( $this->objPicsooWS->IsNullOrEmptyString(trim($picsooitem['item_name'])))
				continue;

			$item = [
				'name'              => isset($picsooitemname) ? (array((int)Configuration::get('PS_LANG_DEFAULT') => $this->ValidateName(substr(trim($picsooitemname),0,125)))) : '',
				'code'              => isset($picsooitem['item_name']) ? trim($picsooitem['item_name']) : '',
				//'description'		=> isset($picsooitem['item_description']) ? trim($picsooitem['item_description']) : '',
				'barcode_symbology' => /*isset($value[2]) ? mb_strtolower(trim($value[2]), 'UTF-8') : ''*/ '',
				'brand'             => '',
				'category_code'     => '',
				'unit'              => 'pc',
				'sale_unit'         => '',
				'purchase_unit'     => '',
				'cost'              => isset($picsooitem['pur_unit_price']) ? trim($picsooitem['pur_unit_price']) : '',
				'price'             => isset($picsooitem['sale_unit_price']) ? trim($picsooitem['sale_unit_price']) : '',
				'alert_quantity'    => '',
				'tax_rate'          => isset($picsooitem['salesvatcode']) ? trim($picsooitem['salesvatcode']) : '',
				'tax_method'        => '', //isset($value[12]) ? (trim($value[12]) == 'exclusive' ? 1 : 0) : '',
				'image'             => '',
				'subcategory_code'  => '',
				'variants'          => '',
				'cf1'               => '',
				'cf2'               => '',
				'cf3'               => '',
				'cf4'               => '',
				'cf5'               => '',
				'cf6'               => '',
				'hsn_code'          => '',
				'second_name'       => '', //isset($value[23]) ? trim($value[23]) : '',
				'supplier1'         => $supplier ? $supplier->id : null,
				'supplier1_part_no' => '',
				'supplier1price'    => '',
				'slug'              => /*$this->sma->slug($value[0]),*/ '',
				'picture'			=> $tmppic,
			];

			if (!empty($item))
			{
				if ($this->process_product($item))
				{
					$cnt++;
				}
			}
			else
			{
			}
		} // foreach ($itemslist as $picsooitem)

		$this->count_transfered = $cnt;
		return $err;
	}

	private function process_product($xproduct)
	{
		try
		{
			$productcode = substr(trim($xproduct['code']),0,63);
			if( $this->ProductExists( $productcode ) )
			{
				if( !$this->ie_updexisting )
					return false;
				
				// + tard
				//$id = $this->GetProductID( $productcode );
				//$my_product = new Product($id); // $id is id number of product to update
				//$my_product->quantity = 1; // $quantity is your desired quantity to set for this product
				//$my_product->save;				
			}
			else
			{
				// https://www.prestashop.com/forums/topic/262781-programmatically-adding-product/
				$product = new Product();              // Create new product in prestashop
				$product->ean13 = '';
				$product->reference = $productcode;
				$product->name = $xproduct['name']; /*array((int)Configuration::get('PS_LANG_DEFAULT') =>  $xproduct['name']);*/ /*$this->createMultiLangField($xproduct['name']);*/
				//$product->description = htmlspecialchars($xproduct['description']); // product description
				$product->id_category_default = '';
				$product->redirect_type = '301';
				$product->price = number_format($xproduct['price'], 6, '.', '');
				$product->minimal_quantity = 1;
				$product->show_price = 1;
				$product->on_sale = 0;
				$product->online_only = 0;
				$product->meta_description = '';
				$product->link_rewrite = $this->createMultiLangField(Tools::str2url($xproduct['name'])); // Contribution credits: mfdenis
				$product->add();                        // Submit new product
				StockAvailable::setQuantity($product->id, null, 1 /*$product['']*/); // id_product, id_product_attribute, quantity
				$product->addToCategories(array(1, 5));     // After product is submitted insert all categories

				if( !$this->objPicsooWS->IsNullOrEmptyString($xproduct['picture']) )
				{
					// add product image.
					$shops = Shop::getShops(true, null, true);
					$image = new Image();
					$image->id_product = $product->id;
					$image->position = Image::getHighestPosition($product->id) + 1;
					$image->cover = true;
					try
					{
						if (($image->validateFields(false, true)) === true && ($image->validateFieldsLang(false, true)) === true && $image->add()) 
						{
							$image->associateTo($shops);
							if (!$this->uploadImage($product->id, $image->id, $xproduct['picture'])) 
							{
								$image->delete();
							}
							unlink( $xproduct['picture'] );
						}
					}
					catch (Exception $e) 
					{
					//echo 'Caught exception: ',  $e->getMessage(), "\n";
					return true;
					}
				}
			}
		}
		catch (Exception $e) 
		{
			//echo 'Caught exception: ',  $e->getMessage(), "\n";
			return false;
		}

		return true;
	}
	
	private function ProductExists( $_productcode )
	{
		$query = 'SELECT count(*) FROM `'._DB_PREFIX_.'product` WHERE `reference` = \'' . $_productcode . '\' ';

        return (bool) Db::getInstance()->getValue($query, false);
	}

	private function GetProductID( $_productcode )
	{
		$query = 'SELECT id_product FROM `'._DB_PREFIX_.'product` WHERE `reference` = \'' . $_productcode . '\' ';

        return Db::getInstance()->getValue($query, false);
	}

	// https://www.prestashop.com/forums/topic/262532-add-image-on-a-product-php/
	private function copyImg($id_entity, $id_image, $url, $entity = 'products', $regenerate = true) 
	{
    	$tmpfile = tempnam(_PS_TMP_IMG_DIR_, 'ps_import');
    	$watermark_types = explode(',', Configuration::get('WATERMARK_TYPES'));


    	switch ($entity) 
    	{
	        default:
        	case 'products':
            	$image_obj = new Image($id_image);
            	$path = $image_obj->getPathForCreation();
            	break;
        	case 'categories':
	            $path = _PS_CAT_IMG_DIR_ . (int) $id_entity;
    	        break;
        	case 'manufacturers':
            	$path = _PS_MANU_IMG_DIR_ . (int) $id_entity;
            	break;
        	case 'suppliers':
            	$path = _PS_SUPP_IMG_DIR_ . (int) $id_entity;
            	break;
    	}
    	$url = str_replace(' ', '%20', trim($url));


    	// Evaluate the memory required to resize the image: if it's too much, you can't resize it.
    	if (!ImageManager::checkImageMemoryLimit($url))
        	return false;


    	// 'file_exists' doesn't work on distant file, and getimagesize makes the import slower.
    	// Just hide the warning, the processing will be the same.
    	if (Tools::copy($url, $tmpfile)) 
    	{
        	ImageManager::resize($tmpfile, $path . '.jpg');
        	$images_types = ImageType::getImagesTypes($entity);


	        if ($regenerate)
	        {
	            foreach ($images_types as $image_type) 
	            {
	                ImageManager::resize($tmpfile, $path . '-' . stripslashes($image_type['name']) . '.jpg', $image_type['width'], $image_type['height']);
	                if (in_array($image_type['id_image_type'], $watermark_types))
	                    Hook::exec('actionWatermark', array('id_image' => $id_image, 'id_product' => $id_entity));
	            }
			}
	    }
	    else 
	    {
	        unlink($tmpfile);
        	return false;
    	}
    	unlink($tmpfile);
    	return true;
	}
	
	public static function ValidateName($name)
    {
		$unwanted_array = array(    'Š'=>'S', 'š'=>'s', 'Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
                            'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
                            'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
                            'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
                            'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y' );

        //return preg_match('/^[^<>;=#{}]*$/u', $name);
		//$string = preg_replace('/[<>;=#{}]/', '', $name);
		$string = str_replace("\r\n", " ", $name); // suppression des \r\n
		//$string = htmlentities($string, ENT_COMPAT, null /*'UTF-8'*/);
    	//$string = preg_replace('/&([a-zA-Z])(uml|acute|grave|circ|tilde);/', '$1', $string); // transformation des caractères accentués en normaux
		$string = strtr( $string, $unwanted_array );
    	$string = html_entity_decode($string);
		$string = preg_replace('/[^a-zA-Z0-9\s,]/', '', $string); // on ne garde que les alphanumériques et la ,

		return $string;
    }

	private function createMultiLangField($field)
	{
		$res = array();
		foreach (Language::getIDs(false) as $id_lang) {
			$res[$id_lang] = $field;
		}
		return $res;
	}
	
	private function uploadImage($id_entity, $id_image = null, $imgUrl)
	{
		$tmpfile = tempnam(_PS_TMP_IMG_DIR_, 'ps_import');
		$watermark_types = explode(',', Configuration::get('WATERMARK_TYPES'));
		$image_obj = new Image((int)$id_image);
		$path = $image_obj->getPathForCreation();
		$imgUrl = str_replace(' ', '%20', trim($imgUrl));
		// Evaluate the memory required to resize the image: if it's too big we can't resize it.
		if (!ImageManager::checkImageMemoryLimit($imgUrl)) {
			return false;
		}
		if (@copy($imgUrl, $tmpfile)) {
			ImageManager::resize($tmpfile, $path . '.jpg');
			$images_types = ImageType::getImagesTypes('products');
			foreach ($images_types as $image_type) {
				ImageManager::resize($tmpfile, $path . '-' . stripslashes($image_type['name']) . '.jpg', $image_type['width'], $image_type['height']);
				if (in_array($image_type['id_image_type'], $watermark_types)) {
					Hook::exec('actionWatermark', array('id_image' => $id_image, 'id_product' => $id_entity));
				}
			}
		} else {
			unlink($tmpfile);
			return false;
		}
		unlink($tmpfile);
		return true;
	}

	private function getCompanyByName($name)
	{
		return false;
		$q = $this->db->get_where('companies', ['name' => $name], 1);
		if ($q->num_rows() > 0) {
			return $q->row();
		}
		return false;
	}

	private function getCategoryByName($name)
	{
		return false;
		$q = $this->db->get_where('categories', ['name' => $name], 1);
		if ($q->num_rows() > 0) {
			return $q->row();
		}
		return false;
	}

	private function getCategoryById($id)
	{
		return false;
		$q = $this->db->get_where('categories', ['id' => $id], 1);
		if ($q->num_rows() > 0) {
			return $q->row();
		}
		return false;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessExportArticles()
	{
		$err = 0;
		$ccount = 0;
		$this->ErrNumber = 0;
		$PassNumber = 1;
		$myList = array();
		$arrLength = count($myList);

		$logtype = 'info';
		//$this->log_message($logtype, 'Export products to Picsoo starts (' . $this->ie_clientsid . ')' );

		$id_lang = Tools::getValue('export_language');
		$id_shop = (int)$this->context->shop->id;

		set_time_limit(0);

		$export_tax = Tools::getValue('export_tax');
		$export_active = (Tools::getValue('export_active') == 0 ? false : true);
		$export_category = (Tools::getValue('export_category') == 99999 ? false : Tools::getValue(
		'export_category'
		));

/*$products = Product::getProducts(
$id_lang,
0,
0,
'id_product',
'ASC',
$export_category,
$export_active
);*/

		$id_lang = (int)Context::getContext()->language->id;
		$start = 0;
		$limit = 0;
		$order_by = 'id_product';
		$order_way = 'DESC';
		$id_category = false;
		$only_active = true;
		$context = null;

		$products = Product::getProducts($id_lang, $start, $limit, $order_by, $order_way, $id_category, $only_active ); //, $context ﻿);﻿

		//		$products_all = Product::getProductsProperties($id_lang, $products);
		//		foreach ($products_all as $product_all)
		//		{
		//			$attr_id = $product_all[id_product_attribute];
		//$product_attr = Product::getAttributeCombinationsById($attr_id, $id_lang); // crash !!
		//var_dump($product_attr);
		//		}

		foreach ($products as $product)
		{
			$p = new Product( $product['id_product'], $id_lang );
			//$ac = $p->getAttributeCombinations();
			//$this->context->smarty->assign('all_combinations', ($p->getAttributeCombinations()));
			$this->context->smarty->assign('all_combinations', (new Product($product['id_product']))->getAttributeCombinations());

			$q = $p->quantity; // QuantityType
			//echo $product->minimal_quantity; // Get product minimum quantity
			//echo $product->low_stock_threshold; // Get product low stock threshold
			//echo $product->low_stock_alert; // Get product low stock alert
			//$attributes = $p->getAttributesResume($this->context->language->id);

			$images = Image::getImages($id_lang, $product['id_product'], $idProductAttribute = null);
			$list_images = array();
			foreach ($images as $img)
			{
				$link = new Link();
				$image = new Image($img['id_image']);
				$image_url = _PS_BASE_URL_._THEME_PROD_DIR_.$image->getExistingImgPath().".jpg";
				//$image_url = $_SERVER['DOCUMENT_ROOT'] . '/' . $image->getExistingImgPath().".jpg";
				array_push($list_images,$image_url);
			}


			file_put_contents('product.txt', print_r($product, true));
			//$images = Product::getCover($product['id_product']);
			//$image_url = $this->context->link->getImageLink($product['link_rewrite'], $images['id_image'], ImageType::getFormatedName('home'));
			//$image_url = $this->getImageLink($product['link_rewrite'], $product.id_image, 'large');
			$image_url = $list_images[0];
			//if (file_exists($image_url))
			if (@getimagesize($image_url))
			{
				$image_name = isset($product['name']) ? trim($product['name']) : 'pic';
				$image_data = file_get_contents($image_url);
				$image_base64 = base64_encode($image_data);
				//file_put_contents('image_base84.txt', print_r($image_base64, true));
			}
			else
			{
				$image_base64 = '';
				$image_name = '';
			}

			if ( isset($product['rate']) )
				$rate = $product['rate'];
			else
				$rate = 0;
			if ( isset($product['price']) )
			{
				$saleunitpricevat = round(($product['price'] + (($product['price'] * $rate) / 100)), 2);;
			}
			else
			{
				$saleunitpricevat = 0;
			}

			$datatosend = [
				'ItemName' => isset($product['name']) ? trim($product['name']) : '',
				'ItemNomianlCode' => isset($product['name']) ? trim($product['name']) : '',
				'FRItemDescription' => isset($product['description']) ? trim($this->cleanproductdes( $product ['description'] )) : '',
				'NLItemDescription' => '',
				'ItemDescription' => isset($product['description_short']) ? trim( $this->cleanproductdes( $product['description_short']) ): '',
				'WarehouseName' => isset($product['location']) ? trim($product['location']) : '',
				'CategoryName' => '',
				'ItrackthisItem' => true,
				'IPuchasethisItem' => true,
				'ISalethisItem' => true,
				'SaleAccountName' => '700000',
				'SaleUnitPrice' => isset($product['price']) ? trim($product['price']) : '', // sale price excluded vat
				'SaleUnitPriceVat' => $saleunitpricevat, // sale price included vat
				'SalesVatCode' => isset($product['rate']) ? trim($product['rate']) : '',
				'VATCodesalesCredit' => isset($product['rate']) ? trim($product['rate']) : '',
				'PurAccountName' => '600000',
				'PurUnitPrice' => isset($product['wholesale_price']) ? trim($product['wholesale_price']) : '', // purchase price excluded vat
				'Multiplier' => '',
				'CostPrice' => '',
				'PurchaseVatCode' => '21',
				'VATCodePurchaseCredit' => '',
				'SupplierName' => isset($product['supplier_reference']) ? trim($product['supplier_reference']) : '',
				'MPN' => '',
				'ISBN' => isset($product['isbn']) ? trim($product['isbn']) : '',
				'EAN' => isset($product['ean13']) ? trim($product['ean13']) : '',
				'brand' => isset($product['manufacturer_name']) ? trim($product['manufacturer_name']) : '',
				'netweight' => isset($product['weight']) ? trim($product['weight']) : '',
				'brutoweight' => isset($product['weight']) ? trim($product['weight']) : '',
				'CPU' => '',
				'StockMinimum' => isset($product['minimal_quantity']) ? trim($product['minimal_quantity']) : '',
				'StockMaximum' => '',
				'Picture' => $image_base64,
				'FileName' => $image_name,
				'ReferenceExternal' => $this->ie_reference,

				'Quantity' => $p->quantity,
			];

			$quantitytosend = [
				'AdjustDate' => date('m-d-Y'),
				'AdjustmentQuantity' => $p->quantity,// qty to increse or decrese
				'CalculateMode' => 2, // 1 for decrese 2 for increse
				//'ClientId' => "10568",
				'ItemName' => isset($product['name']) ? trim($product['name']) : '',
				'Notes' => '',
				'WarehouseName' => '',
				'Price' => isset($product['wholesale_price']) ? trim($product['wholesale_price']) : '', // purchase price excluded vat - required only for increse Calculate mode 2
				'AccountCode' => '700000', // by default 300000 account code if this field not added

			];

			// ==============================================================================================================================================
			// envoi vers Picsoo web ========================================================================================================================
			// ==============================================================================================================================================

/* DH DEBUG */
			//$myfile = fopen("items_log.txt", "w") or die("Unable to open file!");
			//$results = print_r($datatosend, true); // $results now contains output from print_r
			//fwrite($myfile, $results /*serialize($datatosend)*/);
			//fclose($myfile);

			$myList[] = $datatosend;
			$myQty[] = $quantitytosend;

			$ccount++;
			if ( $ccount == 1000 )
			{
				$arrLength = count($myList);
				//fwrite($myfile, $myList); //DBG
				//if( $CurrentMvt==2 ) //DBG
				$result = $this->objPicsooWS->SaveItemsList($this->ie_clientsid, $myList);

				$logtype = 'info';

				if ( $result['IsSuccess'] == false )
				{
					$this->ErrNumber++;
					if ( $result['Message'] == 'Authcode Expired' )
					{
						$this->genmsg = ' (AE)';
						//$this->session->set_flashdata('error', $msg );
						//$logtype = 'error';

						//$this->log_message($logtype, 'Export products to Picsoo aborted (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
						return;
					}
				}
				else
				{
					$this->SendQuantities( $myQty );
				}
				$myList = array();
				$myQty = array();
				$arrLength = count($myList);
				$PassNumber++;
				//if ( $PassNumber == 2 )
				//	break;
			}

			//$this->objPicsooWS->SaveItems($this->ie_clientsid, $datatosend);
		}

		$arrLength = count($myList);
		if ( $arrLength != 0 )
		{
			$result = $this->objPicsooWS->SaveItemsList($this->ie_clientsid, $myList);

			//$msg = $this->lang('export_finished');
			if ( $result['IsSuccess'] == false )
			{
				$this->ErrNumber++;
				$this->genmsg = $result['Message'];
				//$this->session->set_flashdata('error', $msg );
				//$logtype = 'error';
			}
			else
			{
				$this->SendQuantities( $myQty );
				$this->genmsg =  'Les données ont été traitées dans Picsoo POS et sont en cours de transfert vers Picsoo comptabilité/gestion.<br>Ce transfert peut être assez long et prendre plusieurs minutes. Un e-mail de confirmation vous sera envoyé dès finalisation des importations; si la quantité de données est importante, vous pourriez recevoir plusieurs emails.';
				//$msg .= $this->lang('awaiting_email');
				//$this->session->set_flashdata('message', $msg );
				//$logtype = 'info';
			}
		}
		//$this->log_message($logtype, 'Export products to Picsoo (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );

		//$logtype = 'info';
		//$this->log_message($logtype, 'Export products to Picsoo ends (' . $this->ie_clientsid . ')' );

		return $err;
	}

	private function cleanproductdes( $_productdes )
	{
		$ret = '';

		$ret = str_replace("<p>", "",$_productdes);
		$ret = str_replace("</p>", "",$ret);

		return $ret;
	}

	private function SendQuantities( $myQty )
	{
		foreach ( $myQty as $quantity)
		{
			$result = $this->objPicsooWS->StockAdjustement($this->ie_clientsid, $quantity);
			if ( $result['IsSuccess'] == false )
			{
				$this->ErrNumber++;
				$this->genmsg = $result['Message'];
				//$this->session->set_flashdata('error', $msg );
				//$logtype = 'error';
			}
			else
			{
				$this->genmsg = ' - Les données ont été traitées dans Picsoo POS et sont en cours de transfert vers Picsoo comptabilité/gestion.<br>Ce transfert peut être assez long et prendre plusieurs minutes. Un e-mail de confirmation vous sera envoyé dès finalisation des importations; si la quantité de données est importante, vous pourriez recevoir plusieurs emails.';
				//$this->session->set_flashdata('message', $msg );
				//$logtype = 'info';
			}
		}
	}

/*private function getImageLink($name, $ids, $type = null)
{
return ($this->allow == 1) ? (__PS_BASE_URI__.$ids.($type ? '-'.$type : '').'/'.$name.'.jpg') : (_THEME_PROD_DIR_.$ids.($type ? '-'.$type : '').'.jpg');
}*/

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessImportCompanies( $companiestype = '' )
	{
		$err = 0;
		$groupname = '';
		$cnt = 0;

		$customerslist = $this->objPicsooWS->GetCustomersList($this->ie_clientsid);
		$this->count_total = count($customerslist);

		//$titles  = array_shift($arrResult);
		$updated = 0;
		$rw      = 1;
		$items   = [];

		$customer_group = ''; //$this->site->getCustomerGroupByID($this->Settings->customer_group);
		$price_group    = ''; //$this->site->getPriceGroupByID($this->Settings->price_group);

		//set_time_limit(0);

		foreach ($customerslist as $picsoocustomer)
		{
			//$cnt++;
			if ( $picsoocustomer['is_deleted'] == true )
				continue;

			if ( $companiestype == 'C' )
			{
				if ( $picsoocustomer['EnumCustomerTypeID'] == '2' )
					continue;
				$groupname = 'customer';
			}
			else if ( $companiestype == 'S' )
			{
				if ( $picsoocustomer['EnumCustomerTypeID'] == '1' )
					continue;
				$groupname = 'supplier';
			}
			else
				continue;

			if( $cnt>100 )
				break;
			//if( $picsoocustomer['email_address'] != 'o.pigeon@4must.be' )
			//	continue;
			
/* DH DEBUG */
			//$myfile = fopen("customers_log.txt", "a") or die("Unable to open file!");
			//$results = print_r($picsoocustomer['customer_company_name']."\n", true); // $results now contains output from print_r
			//fwrite($myfile, $results);
			//fclose($myfile);

			$adresses = $this->objPicsooWS->GetCustomerAddress($this->ie_clientsid, $picsoocustomer['customers_id']);
			$belgiuminfo = $this->objPicsooWS->GetCustomerBelgiumInformation($this->ie_clientsid, $picsoocustomer['customers_id']);

			$cc = '';
			if ( isset($picsoocustomer['Customercode']) )
				$cc = trim($picsoocustomer['Customercode']);
			else
			{
				if ( $companiestype == 'C' )
					$cc = "400000";
				else
					$cc = "440000";
			}

			$customer = [
				'company'             	=> isset($picsoocustomer['customer_company_name']) ? trim($picsoocustomer['customer_company_name']) : '',
				'name'                	=> isset($picsoocustomer['customer_company_name']) ? trim($picsoocustomer['customer_company_name']) : '',
				'firstname'				=> isset($picsoocustomer['first_name']) ? trim($picsoocustomer['first_name']) : '',
				'lastname'				=> isset($picsoocustomer['last_name']) ? trim($picsoocustomer['last_name']) : '',
				'title'					=> isset($picsoocustomer['title']) ? trim($picsoocustomer['title']) : '',
				'email'               	=> isset($picsoocustomer['email_address']) ? trim($picsoocustomer['email_address']) : '',
				'phone'               	=> isset($picsoocustomer['primary_contact']) ? trim($picsoocustomer['primary_contact']) : '',
				'address'             	=> isset($adresses['address_1']) ? trim($adresses['address_1']) : '',
				'city'                	=> isset($adresses['ccity']) ? trim($adresses['ccity']) : '',
				'state'               	=> isset($adresses['state_name']) ? trim($adresses['state_name']) : '',
				'postal_code'         	=> isset($adresses['cpostcode']) ? trim($adresses['cpostcode']) : '',
				'country'             	=> isset($adresses['country']) ? trim($adresses['country']) : '',
				'vat_no'              	=> isset($belgiuminfo['VATNumber']) ? trim($belgiuminfo['VATNumber']) : '',
				'gst_no'              	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'account_code'			=> $cc,
				'cf1'                 	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'cf2'                 	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'cf3'                 	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'cf4'                 	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'cf5'                 	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'cf6'                 	=> '', //isset($picsooitem['item_nomianlcode']) ? trim($picsooitem['item_nomianlcode']) : '',
				'group_id'            	=> 3,
				'group_name'          	=> $groupname,
				'customer_group_id'   	=> '', //(!empty($customer_group)) ? $customer_group->id : null,
				'customer_group_name' 	=> '', //(!empty($customer_group)) ? $customer_group->name : null,
				'price_group_id'      	=> (!empty($price_group)) ? $price_group->id : null,
				'price_group_name'    	=> (!empty($price_group)) ? $price_group->name : null,
			];
			$var1 = $customer['vat_no'];

			if ( empty($customer['firstname']))
				$customer['firstname'] = "NOT SET";
			if ( empty($customer['lastname']))
				$customer['lastname'] = "NOT SET";
			if ( empty($customer['email']))
				$customer['email'] = "not_set@company.com";
			if ( empty($customer['address']))
				$customer['address'] = "NOT SET";
			if ( empty($customer['city']))
				$customer['city'] = "NOT SET";
			if ( empty($customer['postal_code']))
				$customer['postal_code'] = "NOT SET";

/* code controllers\admin\Customers.php >> function import_csv() */
			if (empty($customer['company']) || empty($customer['name']) )
			{
				//$this->session->set_flashdata('error', $this->lang('company') . ', ' . $this->lang('name') . ', ' . $this->lang('email') . ' ' . $this->lang('are_required') . ' (' . $this->lang('line_no') . ' ' . $rw . ')');
				//admin_redirect('picsoo/import_export' );
				continue;
			}
			else
			{
			}

			if (!empty($customer))
			{
				if ($this->add_customers($customer))
				{
					$cnt++;
					//$updated = $updated ? '<p>' . sprintf($this->lang('products_updated'), $updated) . '</p>' : '';
					//$this->session->set_flashdata('message', sprintf($this->lang('products_added'), count($items)) . $updated);
					//admin_redirect('picsoo');
				}
			}
			else
			{
			}
		} // foreach ($customerslist as $picsoocustomer)

		$this->count_transfered = $cnt;
		return $err;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessExportCompanies( $companiestype = ''  )
	{
		$err = 0;
		$ccount = 0;
		$this->ErrNumber = 0;
		$PassNumber = 1;
		$myList = array();
		$arrLength = count($myList);
		$nbcompanies = 0;

		$logtype = 'info';

		$customersInfo = $this->_getCustomerInfo();

		foreach ($customersInfo as $customer)
		{
			// on test si la company est utilisées dans les transactions; si pas, on ne la prend pas !
			//$cc = new Customer($customer['id_customer']);
			$oo = Order::getCustomerOrders($customer['id_customer']/*$cc->id*/);
			if (!$oo || !count($oo))
				continue;				
			//if ( !$cc->getBoughtProducts() )
			//if ( !$this->IsCompanyInSales( $customer['id_customer'] ))
			//	continue;

			$addressesInfo = [];
			$addressesInfo = $this->_getCustomerAddress($customer['id_customer']);
	
			$nbcompanies++;

			if ( $companiestype == 'C' )
				$customer['account_code'] = '400' . strtoupper($customer['lastname']);
			else
				$customer['account_code'] = '440' . strtoupper($customer['lastname']);
			
			$datatosend = [
				'Mode'                      => '', // Mode - 0 To Insert And 1 To Update
				'UserID'                    => '',
				'ClientId'                  => $this->ie_clientsid,
				'CompanyName'               => $customer['firstname'] . ' ' . $customer['lastname'],
				'AccountCode'               => '',
				'CustomerCode'				=> $customer['account_code'],
				'Title'                     => '',
				'FirstName'                 => '',
				'LastName'                  => $customer['firstname'],
				'Email'                     => $customer['email'],
				'PrimaryPhone'              => $addressesInfo['phone'],
				'ContactType'               => '',
				'BillingAddressLine1'		=> $addressesInfo['address1'],
				'BillingAddressLine2'		=> $addressesInfo['address2'],
				'BillingPostalCode'         => $addressesInfo['postcode'],
				'BillingCity'               => $addressesInfo['city'],
				'BillingState'              => $addressesInfo['statename'],
				'BillingCountry'            => $addressesInfo['country'],
				'DeliveryAddressLine1'		=> $addressesInfo['address1'],
				'DeliveryAddressLine2'		=> $addressesInfo['address2'],
				'DeliveryPostalCode'		=> $addressesInfo['postcode'],
				'DeliveryCity'              => $addressesInfo['city'],
				'DeliveryState'             => $addressesInfo['statename'],
				'DeliveryCountry'           => $addressesInfo['country'],
				'Website'                   => $customer['website'],
				'BankName'                  => '',
				'AccountName'               => '',
				'AccountNumber'             => '',
				'OtherDetail'               => '',
				'SecondaryPhone'            => '',
				'vatNumber'                 => $addressesInfo['vat_number'],
				'Skype'                     => '',
				'Facebook'                  => '',
				'Twitter'                   => '',
				'Reconciliation'            => '',
				'TaxReport'                 => '',
				'Reminder'                  => '',
				'EuropeanVatNo'             => $addressesInfo['vat_number'],
				'Vatcode'                   => '',
				'DueDate'                   => '',
				'BusinesType'               => '',
				'Category'                  => '',
				'Discount'                  => '',
				'Notes'                     => '',
				'VatCodePurchaseCredit'		=> '',
				'VatCodeSalesCredit'		=> '',
				'Item'                      => '',
				'Languages'                 => '',
				'Type'                      => '',
				'Deleted'                   => '',
				'IBAN'                      => '',
				'BIC'                       => '',
				// vrs 1.1.27 - ajout de ce champs
				'ReferenceExternal'         => $this->ie_reference,

				//'Id' => 0,
				//'UserID' => 2,
				//'FKAccountnameId' => 0,
			];

			// ==============================================================================================================================================
			// envoi vers Picsoo web ========================================================================================================================
			// ==============================================================================================================================================

/* DH DEBUG */
			//$myfile = fopen("customers_log.txt", "w") or die("Unable to open file!");
			//$results = print_r($datatosend, true); // $results now contains output from print_r
			//fwrite($myfile, $results /*serialize($datatosend)*/);
			//fclose($myfile);

			$myList[] = $datatosend;

			$ccount++;
			if ( $ccount == 1000 )
			{
				$arrLength = count($myList);
				//fwrite($myfile, $myList); //DBG
				//if( $CurrentMvt==2 ) //DBG
				$result = $this->objPicsooWS->SaveCustomersSuppliersList($this->ie_clientsid, $myList, $companiestype);
				if ( $result['IsSuccess'] != true && $result['IsSuccess']!='' )
					$this->ErrNumber++;

				$logtype = 'info';
				if ( $companiestype == 'C' )
				{
					//$this->log_message($logtype, 'Export customers to Picsoo (' . $this->ie_clientsid . ') - Pass# : ' . $PassNumber . ' - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
				}
				else
				{
					//$this->log_message($logtype, 'Export suppliers to Picsoo (' . $this->ie_clientsid . ') - Pass# : ' . $PassNumber . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
				}

				if ( $result['IsSuccess'] == false )
				{
					if ( $result['Message'] == 'Authcode Expired' )
					{
						$this->genmsg = 'Export finished' . ' - ' . 'Try later' . ' (AE).';
						//$this->session->set_flashdata('error', $msg );
						$logtype = 'error';

						if ( $companiestype == 'C' )
						{
							//$this->log_message($logtype, 'Export customers to Picsoo aborted (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
						}
						else
						{
							//$this->log_message($logtype, 'Export suppliers to Picsoo aborted (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
						}
						return;
					}
				}
				$myList = array();
				$arrLength = count($myList);
				$PassNumber++;
				//if ( $PassNumber == 2 )
				//	break;
			}

			//$this->objPicsooWS->SaveCustomers($this->ie_clientsid, $datatosend, $companiestype);
		}

		$arrLength = count($myList);
		if ( $arrLength != 0 )
		{
			$result = $this->objPicsooWS->SaveCustomersSuppliersList($this->ie_clientsid, $myList, $companiestype);

			$logtype = 'info';
			if ( $companiestype == 'C' )
			{
				//$this->log_message($logtype, 'Export customers to Picsoo (' . $this->ie_clientsid . ') - Pass# : ' . $PassNumber . ' - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
			}
			else
			{
				//$this->log_message($logtype, 'Export suppliers to Picsoo (' . $this->ie_clientsid . ') - Pass# : ' . $PassNumber . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
			}
		}

		$msg = 'export_finished';
		if ( $result['IsSuccess'] != true )
		{
			$this->genmsg = $result['Message'];
			//$this->session->set_flashdata('error', $msg );
			$logtype = 'error';
		}
		else
		{
			$this->genmsg = 'Les données ont été traitées dans Picsoo POS et sont en cours de transfert vers Picsoo comptabilité/gestion.<br>Ce transfert peut être assez long et prendre plusieurs minutes. Un e-mail de confirmation vous sera envoyé dès finalisation des importations; si la quantité de données est importante, vous pourriez recevoir plusieurs emails.';
			$this->genmsg .= ' <br>(INFO : ' . $nbcompanies . ' clients à transférer = ' . ((($nbcompanies / 100 ) * 10) + 10) . ' minutes d\'attente)';
			//$this->session->set_flashdata('message', $msg );
			$logtype = 'info';
		}

		if ( $companiestype == 'C' )
		{
			//$this->log_message($logtype, 'Export customers to Picsoo (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
		}
		else
		{
			//$this->log_message($logtype, 'Export suppliers to Picsoo (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
		}

		$logtype = 'info';

		if ( $companiestype == 'C' )
		{
			//$this->log_message($logtype, 'Export customers to Picsoo ends (' . $this->ie_clientsid . ')' );
		}
		else
		{
			//$this->log_message($logtype, 'Export suppliers to Picsoo ends (' . $this->ie_clientsid . ')' );
		}

		return $err;
	}

	private function _getCustomerInfo()
	{
		$sql='SELECT * '
		.' FROM '._DB_PREFIX_.'customer';

		$result = Db::getInstance()->executeS($sql);
		//		die(var_dump($result));
		return $result;
	}

	private function _getCustomerInfox()
	{
		$languageid= $this->context->language->id;
		// 		$cklanguageid=Tools::getValue('ckcustomerselectlanuage');
		// 		if ($cklanguageid>0)
		// 		{
		// 			$languageid=$cklanguageid;
		// 		}
		$shopid =$this->context->shop->id;
		$datefrom=Tools::getValue('customerdatefrom');
		$dateto=Tools::getValue('customerdateto');
		$sql='SELECT c.id_customer as customerid, c.firstname as firstname ,c.lastname as lastname,c.email as email ,c.active as active,c.deleted as deleted,'.
		'gl.name as groupname '
		.' FROM '._DB_PREFIX_.'customer c  LEFT JOIN '._DB_PREFIX_.'group_lang gl ON gl.id_group=c.id_default_group '
		.' WHERE gl.id_lang='.$languageid.
		' and  c.date_add >"'.$datefrom.'" and c.date_add < "'.$dateto.'" and c.id_shop='.$shopid;

		$result = Db::getInstance()->executeS($sql);
		//		die(var_dump($result));
		return $result;
	}

	private function _getCustomerAddress($customerid)
	{
		$languageid= $this->context->language->id;
		// 		$cklanguageid=Tools::getValue('ckcustomerselectlanuage');
		// 		if ($cklanguageid>0)
		// 		{
		// 			$languageid=$cklanguageid;
		// 		}
		$sql='SELECT ad.alias as adressalias , ad.company as company ,ad.address1 as address1,ad.address2 as address2,'.
		'ad.postcode as postcode,ad.city as city,ad.phone as phone,ad.phone_mobile as mobile,'
		.'ad.other as other, ad.vat_number as vat_number, st.name as statename, ad.deleted as deleted, cl.name as country FROM '
		._DB_PREFIX_.'address ad LEFT JOIN '._DB_PREFIX_.'country_lang cl on ad.id_country=cl.id_country
		LEFT JOIN '._DB_PREFIX_.'state st ON ad.id_state=st.id_state
		WHERE ad.id_customer='.$customerid .' and cl.id_lang='.$languageid.
		' and ad.deleted=0';

		return Db::getInstance()->executeS($sql);
	}

	// https://www.prestashop.com/forums/topic/512628-comment-obtenir-le-dernier-achat-dun-client-%C3%A0-partir-dun-autre-module/
	public function IsCompanyInSales( $_cpyid )
	{
		$sql = 'SELECT od.product_id, od.product_attribute_id '.
		'FROM ps_orders o '.
		'LEFT JOIN ps_orders o2 on o2.id_customer = o1.id_customer and o2.id_order > o1.id_order '.
		'INNER JOIN ps_order_detail od on od.id_order = o.id_order '.
		'WHERE o.id_customer = '.$_cpyid.' '.
		'AND o2.id_order is null';
		
		$result = Db::getInstance()->execute($sql);
		
		//$q = $this->db->get_where('sales', ['customer_id' => $_cpyid], 1);
		//if ($q->num_rows() > 0)
		//{
			return true;
		//}
		//return false;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessExportTransactionsTEST( )
	{
		return; // + tard
		$orders = Order::getOrdersWithInformations((int) Configuration::get('DASHPRODUCT_NBR_SHOW_LAST_ORDER', 10));
		$body = array();
		foreach ($orders as $order)
		{
			$o = new Order( (int)$order['id_order'] );

			$d = $o->getOrderDetailList();
			
			$currency = Currency::getCurrency((int) $order['id_currency']);
			$tr = array();
			$tr[] = array('id' => 'firstname_lastname', 'value' => Tools::htmlentitiesUTF8($order['firstname']) . ' ' . Tools::htmlentitiesUTF8($order['lastname']), 'class' => 'text-left');
			$tr[] = array('id' => 'state_name', 'value' => count(OrderDetail::getList((int) $order['id_order'])), 'class' => 'text-center');
			$tr[] = array('id' => 'total_paid', 'value' => Tools::displayPrice((double) $order['total_paid'], $currency), 'class' => 'text-center', 'wrapper_start' => '<span class="badge">', 'wrapper_end' => '<span>');
			$tr[] = array('id' => 'date_add', 'value' => Tools::displayDate($order['date_add']), 'class' => 'text-center');
			$tr[] = array('id' => 'details', 'value' => $this->l('Details'), 'class' => 'text-right', 'wrapper_start' => '<a class="btn btn-default" href="index.php?tab=AdminOrders&id_order=' . (int) $order['id_order'] . '&vieworder&token=' . Tools::getAdminTokenLite('AdminOrders') . '" title="' . $this->l('Details') . '"><i class="icon-search"></i>', 'wrapper_end' => '</a>');
			$body[] = $tr;
		}
	}

	private function ProcessExportTransactionsTEST1( )
	{
		$timestampS = (int)Tools::getValue('date');
		$timestampE = $timestampS + $this->_weekToSeconds();
		$dateStart	= date('Y-m-d H:i:s', $timestampS);
		$dateEnd		= date('Y-m-d H:i:s', $timestampE);

		$results = $this->_getResultAdmin($dateStart, $dateEnd, (int)Tools::getValue('order_state'));
		//$titles	 = $this->_getTitlesAdmin($results);
		$type		 = $this->l('admin');
		$dirType = 'admin/';
	}
	
	private function _getResultAdmin($dateStart, $dateEnd, $orderState)
	{
		global $cookie;

		if ($orderState != 0)
			$state = " AND oh.`id_order_state` = " . $orderState;
		else
			$state = "";
		/*$sql = "SELECT SQL_CALC_FOUND_ROWS o.`id_order` AS `o.id_order`,
									 (SELECT COUNT(oddd.`id_order_detail`) FROM `" . _DB_PREFIX_ . "order_detail` oddd WHERE oddd.`id_order_detail` >= od.`id_order_detail` AND oddd.`id_order` = od.`id_order`) AS `nb_product`,
									 (SELECT COUNT(odd.`id_order`) FROM `" . _DB_PREFIX_ . "order_detail` odd WHERE odd.`id_order` = od.`id_order`) AS `nb_total`,
									 o.`date_add` AS `o.date_add`,
									 od.`product_reference` AS `od.product_reference`,
									 m.`name` AS `m.name`,
									 od.`product_name` AS `od.product_name`,
									 (SELECT GROUP_CONCAT(agl.`id_attribute_group` ORDER BY agl.`id_attribute_group` ASC SEPARATOR '#')
										FROM `" . _DB_PREFIX_ . "product_attribute` pa
										LEFT JOIN `" . _DB_PREFIX_ . "product_attribute_combination` pac ON (pac.`id_product_attribute` = pa.`id_product_attribute`)
										LEFT JOIN `" . _DB_PREFIX_ . "attribute` a ON (a.`id_attribute` = pac.`id_attribute`)
										LEFT JOIN `" . _DB_PREFIX_ . "attribute_group_lang` agl ON (agl.`id_attribute_group` = a.`id_attribute_group` AND agl.`id_lang` = " . (int)$cookie->id_lang . ")
										WHERE pa.`id_product_attribute` = od.`product_attribute_id`) AS `agl.id_attribute_group`,
									 (SELECT GROUP_CONCAT(al.`name` ORDER BY al.`name` ASC SEPARATOR '#')
										FROM `" . _DB_PREFIX_ . "product_attribute` pa
										LEFT JOIN `" . _DB_PREFIX_ . "product_attribute_combination` pac ON (pac.`id_product_attribute` = pa.`id_product_attribute`)
										LEFT JOIN `" . _DB_PREFIX_ . "attribute` a ON (a.`id_attribute` = pac.`id_attribute`)
										LEFT JOIN `" . _DB_PREFIX_ . "attribute_lang` al ON (al.`id_attribute` = a.`id_attribute` AND al.`id_lang` = " . (int)$cookie->id_lang . ")
										WHERE pa.`id_product_attribute` = od.`product_attribute_id`) AS `al.name`,
									 od.`product_weight` AS `od.product_weight`,
									 od.`product_quantity` AS `od.product_quantity`,
									 od.`product_price` AS `et_unit_cost`,
									 (od.`product_price` * ((100 + (od.`tax_rate`))/100)) AS `ati_unit_cost`,
									 (od.`product_price` * od.`product_quantity`) AS `et_cost`,
									 (od.`product_price` * ((100 + (od.`tax_rate`))/100) * od.`product_quantity`) AS `ati_cost`,
									 ads.`lastname` AS `delivery_lastname`,
									 ads.`firstname` AS `delivery_firstname`,
									 CONCAT(ads.`address1`, ' ', ads.`address2`) AS `delivery_address`,
									 ads.`postcode` AS `delivery_postcode`,
									 ads.`city` AS `delivery_city`,
									 cld.`name` AS `delivery_country`,
									 adi.`lastname` AS `invoice_lastname`,
									 adi.`firstname` AS `invoice_firstname`,
									 CONCAT(adi.`address1`, ' ', adi.`address2`) AS `invoice_address`,
									 adi.`postcode` AS `invoice_postcode`,
									 adi.`city` AS `invoice_city`,
									 cli.`name` AS `invoice_country`,
									 u.`email` AS `u.email`,
									 osl.`name` AS `osl.name`,
									 o.`gift` AS `o.gift`,
									 o.`gift_message` AS `o.gift_message`
							FROM `" . _DB_PREFIX_ . "orders` o
							LEFT JOIN `" . _DB_PREFIX_ . "order_detail` od ON (od.`id_order` = o.`id_order`)
							LEFT JOIN `" . _DB_PREFIX_ . "product` p ON (p.`id_product` = od.`product_id`)
							LEFT JOIN `" . _DB_PREFIX_ . "manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
							LEFT JOIN `" . _DB_PREFIX_ . "customer` u ON (u.`id_customer` = o.`id_customer`)
							LEFT JOIN `" . _DB_PREFIX_ . "address` ads ON (ads.`id_address` = o.`id_address_delivery`)
							LEFT JOIN `" . _DB_PREFIX_ . "address` adi ON (adi.`id_address` = o.`id_address_invoice`)
							LEFT JOIN `" . _DB_PREFIX_ . "country_lang` cli ON (cli.`id_country` = adi.`id_country` AND cli.`id_lang` = " . (int)$cookie->id_lang . ")
							LEFT JOIN `" . _DB_PREFIX_ . "country_lang` cld ON (cld.`id_country` = ads.`id_country` AND cld.`id_lang` = " . (int)$cookie->id_lang . ")

							LEFT JOIN `" . _DB_PREFIX_ . "tax_rule` tr ON (p.`id_tax_rules_group` = tr.`id_tax_rules_group` AND tr.`id_country` = " . (int)Country::getDefaultCountryId() . " AND tr.`id_state` = 0)
							LEFT JOIN `" . _DB_PREFIX_ . "tax` t ON (t.`id_tax` = tr.`id_tax`)
							LEFT JOIN `" . _DB_PREFIX_ . "order_history` oh ON (oh.`id_order` = o.`id_order`)
							LEFT JOIN `" . _DB_PREFIX_ . "order_state` os ON (os.`id_order_state` = oh.`id_order_state`)
							LEFT JOIN `" . _DB_PREFIX_ . "order_state_lang` osl ON (osl.`id_order_state` = oh.`id_order_state` AND osl.`id_lang` = " . (int)$cookie->id_lang . ")
							WHERE o.date_add BETWEEN '" . $dateStart . "' AND '" . $dateEnd . "'" . $state . "
							ORDER BY o.`id_order` ASC, nb_product ASC";*/
							
		// https://www.mediacom87.fr/en/tip-csv-export-of-order-details-on-prestashop-and-thirtybees/							
		$sql = "SELECT d.id_order, o.date_add,  CONCAT_WS(' ', g.firstname, g.lastname) AS customer,
   					   g.email, os.name AS state, d.product_name, d.product_reference, d.product_quantity, d.product_price,
                       o.payment, c.name AS carrier_name, CONCAT_WS(' ', a.lastname, a.firstname, a.address1, a.address2, a.postcode, a.city) AS address_delivery,
					   CONCAT_WS(' ', a.lastname, a.firstname, a.address1, a.address2, a.postcode, a.city) AS address_invoice,
					   REPLACE(IFNULL(GROUP_CONCAT(cd.value), ''), '\"', '\'') AS customized_data
				FROM ps_order_detail d
				LEFT JOIN ps_orders o ON (d.id_order = o.id_order)
				LEFT JOIN ps_customer g ON (o.id_customer = g.id_customer)
				LEFT JOIN ps_carrier c ON (o.id_carrier = c.id_carrier)
				LEFT JOIN ps_order_state_lang os ON (o.current_state = os.id_order_state)
				LEFT JOIN ps_address a ON (a.id_address = o.id_address_delivery)
				LEFT JOIN ps_address ab ON (ab.id_address = o.id_address_invoice)
				LEFT JOIN ps_customization cu ON (cu.id_cart = o.id_cart)
				LEFT JOIN ps_customized_data cd ON (cd.id_customization = cu.id_customization)
				GROUP BY d.id_order
				ORDER BY d.id_order DESC";					
							
		$results = Db::getInstance()->ExecuteS($sql);
		$datas	 = array();

		foreach ($results as $n => $result)
		{
			foreach ($result as $key => $val)
			{
				if ($key == 'et_unit_cost' || $key == 'ati_unit_cost' || $key == 'et_cost' || $key == 'ati_cost')
					$datas[$n][$key] = Tools::displayPrice($val, $this->_currency, false);
				elseif ($key == 'o.date_add')
					$datas[$n][$key] = Tools::displayDate($val, (int)$cookie->id_lang, false);
				elseif ($key == 'nb_product')
					$datas[$n]['position'] = $val . '/' . $results[$n]['nb_total'];
				elseif ($key == 'od.product_weight')
					$datas[$n][$key] =	$val . Configuration::get('PS_WEIGHT_UNIT');
				elseif ($key == 'osl.name')
				{
					if ($result['nb_product'] == 1)
						$datas[$n][$key] = $val;
				}
				elseif ($key == 'al.name')
				{
					$datas[$n] = $this->_getFeatureArray($datas[$n]);

					if ($result[$key] != '')
					{
						$features = explode('#', $val);
						$featuresIds = explode('#', $result['agl.id_attribute_group']);
						foreach ($features as $k => $feature)
							$datas[$n]['feature_' . $featuresIds[$k]] = $feature;
					}
				}
				elseif ($key == 'nb_total' || $key == 'agl.id_attribute_group')
					continue;
				else
					$datas[$n][$key] = $val;
			}
		}

		return $datas;
	}

	private function _weekToSeconds()
	{
		return 7 * 24 * 60 * 60;
	}

	// --------------------------------------------------------------------------------------------------------------------------------
	//
	// --------------------------------------------------------------------------------------------------------------------------------
	private function ProcessExportTransactions( )
	{
		$err = 0;

		$orders = Order::getOrdersWithInformations((int) Configuration::get('DASHPRODUCT_NBR_SHOW_LAST_ORDER', 10));
		$cnt = (int) count($orders);
		if ( $cnt<=0 )
			return;
		
		$body = array();
		$mvts = 1;
		$this->ximportslist = array();
		$xbadtrans = array(); // contient les transactions dont le débit<>crédit
		
		/* +tard, si pas d'order >> msg d'erreur
		if ($q->num_rows() <= 0)
		{
			$msg = lang('no_transaction');
			$this->session->set_flashdata('error', $msg );
			$logtype = 'error';

			return $err;
		}*/

		$this->vatlist = $this->objPicsooWS->GetValList($this->ie_clientsid);
		/* +tard, si vatlist est nulle > msg d'erreur
		if( $this->vatlist == null )
		{
			$msg = lang('no_vatlist');
			$this->session->set_flashdata('error', $msg );
			$logtype = 'error';

			return $err;
		}*/
		$this->CleanVatList();
		
		foreach ($orders as $order) 
		{
			//if ( ((int)$order['id_order']) != 8 )
			//	continue;
			
			$o = new Order( (int)$order['id_order'] );

			$details = $o->getOrderDetailList();
			$cnt = (int)count($details);
			if ( $cnt > 0 ) 
			{
				$currency = Currency::getCurrency((int) $order['id_currency']);
				/*$tr = array();
				$tr[] = array('id' => 'firstname_lastname', 'value' => Tools::htmlentitiesUTF8($order['firstname']) . ' ' . Tools::htmlentitiesUTF8($order['lastname']), 'class' => 'text-left');
				$tr[] = array('id' => 'state_name', 'value' => count(OrderDetail::getList((int) $order['id_order'])), 'class' => 'text-center');
				$tr[] = array('id' => 'total_paid', 'value' => Tools::displayPrice((double) $order['total_paid'], $currency), 'class' => 'text-center', 'wrapper_start' => '<span class="badge">', 'wrapper_end' => '<span>');
				$tr[] = array('id' => 'date_add', 'value' => Tools::displayDate($order['date_add']), 'class' => 'text-center');
				$tr[] = array('id' => 'details', 'value' => $this->l('Details'), 'class' => 'text-right', 'wrapper_start' => '<a class="btn btn-default" href="index.php?tab=AdminOrders&id_order=' . (int) $order['id_order'] . '&vieworder&token=' . Tools::getAdminTokenLite('AdminOrders') . '" title="' . $this->l('Details') . '"><i class="icon-search"></i>', 'wrapper_end' => '</a>');
				$body[] = $tr;*/

				// le compte client ==============================================================================================================================
				$obj = new Struct_XImport();
				$obj->_MVTS = $mvts; // numéro de mouvement
				$obj->_ID = $order['id_order'];
				$obj->_JOUR = 'VT'; // Code journal
				$obj->_DECR = $order['date_add']; // Date écriture
				$obj->_DECH = $order['date_add']; // Date échéance
				$obj->_NUMP = $order['reference']; // N° de pièce
				$obj->_COMP = '400' . strtoupper($order['lastname']); // N° de compte
				$obj->_LIBE = $order['lastname']; // Libellé écriture
				$obj->_MONT = $order['total_paid_tax_incl']; // Montant
				$obj->_SENS = 'D'; // Sens montant
				$obj->_LETT = ''; // Ref. pointage / lettrage
				$obj->_ANAL = ''; // Code analytique
				$obj->_MTVA = floatval($order['total_paid_tax_incl'])-floatval($order['total_paid_tax_excl']); // Montant total TVA
				$obj->_TTVA = 0.00; // Taux de TVA
				$obj->_CTVA = ''; // Code TVA
				$obj->_GTVA = '';
				$obj->_GBAS = '';

				$this->ximportslist[] = $obj;

				// articles / contreparties ======================================================================================================================

				foreach ( $details as $detail )
				{
					//if( $mvts > 2 ) // DBG
					//{
					//$message = "STOP!";
					//echo "<script type='text/javascript'>alert('$message');</script>";
					//    break;
					//}
					//$ximports = array(); // ré-initialisation du tableau à chaque transaction.

					$total_debit = 0.00;
					$total_credit = 0.00;

					//if( $saleid != 244  ) // DBG
					//    continue;

					$total_debit += $obj->_MONT;

					// product details
					$id_lang = (int)Context::getContext()->language->id;
					$product_detail = new Product( $detail['product_id'], $id_lang );

					$current_cnt = 1;
					$gtotal_tva = 0.00;  // total général de tva pour gestion arrondi final
					$gtotal_htva = 0.00; // total général htva pour gestion arrondi final

					// contrepartie ----------------------------------------------------------------------------
					
					$obj = new Struct_XImport();
					$obj->_MVTS = $mvts;
					$obj->_ID = $order['id_order'];
					$obj->_JOUR = 'VT'; // Code journal
					$obj->_DECR = $order['date_add']; // Date écriture
					$obj->_DECH = $order['date_add']; // Date échéance
					$obj->_NUMP = $order['reference']; // N° de pièce
					$obj->_COMP = '700000'; // N° de compte
					$obj->_LIBE = $order['lastname']; // Libellé écriture
					$montant_htva = floatval( $detail['total_price_tax_excl']);
					$obj->_MONT = $montant_htva; // Montant
					$gtotal_htva += $obj->_MONT;
					$obj->_SENS = 'C'; // Sens montant
					$obj->_LETT = ''; // Ref. pointage / lettrage
					$obj->_ANAL = ''; // Code analytique
					$obj->_MTVA = 0.00; // Montant TVA
					$obj->_TTVA = $detail['tax_rate']; // Taux de TVA
					$obj->_CTVA = $this->GetCodeTva($detail['tax_name']); // Code TVA
					$obj->_GTVA = '';
					$obj->_GBAS = '3'; // accountgrid - 3 : cf Philippe 4/10/2022 skype

					if ( $obj->_MONT != 0.00 ) 
					{
						$total_credit += $obj->_MONT;
						$this->ximportslist[] = $obj;
					}

					//if( $header->grand_total == 3230.00 )
					//{
					//    $dbg = 'ZZZ';
					//}

					// remise globale
					/*if ( floatval($detail['reduction_percent']) != 0.00 ) 
					{
						$obj = new Struct_XImport();
						$obj->_MVTS = $mvts;
						$obj->_ID = $order['id_order'];
						$obj->_JOUR = 'VT'; // Code journal
						$obj->_DECR = $order['date_add']; // Date écriture
						$obj->_DECH = $order['date_add']; // Date échéance
						$obj->_NUMP = $order['reference']; // N° de pièce
						$obj->_COMP = '700000'; // N° de compte
						$obj->_LIBE = $order['lastname']; // Libellé écriture
						$tot = $order['total_paid_tax_incl'] + $header->order_discount;
						$total_htva = ($header->order_discount / $tot) * $montant_htva;
						$obj->_MONT = $this->roundMoney($total_htva,0.01); // Montant
						$gtotal_htva -= $obj->_MONT;
						$obj->_SENS = 'D'; // Sens montant
						$obj->_LETT = ''; // Ref. pointage / lettrage
						$obj->_ANAL = ''; // Code analytique
						$obj->_MTVA = 0.00; // Montant TVA
						$obj->_TTVA = $detail['tax_rate']; // Taux de TVA
						$obj->_CTVA = $this->GetCodeTva($detail['tax_name']); // Code TVA

						if ( $obj->_MONT != 0.00 ) 
						{
							$total_debit -= $obj->_MONT;
							$this->ximportslist[] = $obj;
						}
					}*/

					// tva -------------------------------------------------------------------------------------

					foreach ($this->vatlist as $vatlistline)
					{
						if ( $detail['tax_name'] == $vatlistline['CODE'] )
						{
							$obj = new Struct_XImport();
							$obj->_MVTS = $mvts;
							$obj->_ID = $order['id_order'];
							$obj->_JOUR = 'VT'; // Code journal

							$obj->_TTVA = $vatlistline['VATPercent']; //$tax_rate->rate; // Taux de TVA
							$obj->_CTVA = $vatlistline['CODE']; //$tax_rate->code; // Code TVA
							$obj->_GTVA = $vatlistline['VATGrid'];
							$obj->_GBAS = '';
							$obj->_DECR = $order['date_add']; // Date écriture
							$obj->_DECH = $order['date_add']; // Date échéance
							$obj->_NUMP = $order['reference']; // N° de pièce
							$obj->_COMP = '451540'; // N° de compte
							$obj->_LIBE = $order['lastname']; // Libellé écriture
							//$montant_tva = $saleline->item_tax * $saleline->quantity;
							$obj->_MONT = floatval($detail['total_price_tax_incl']) - floatval($detail['total_price_tax_excl']); // Montant
							$gtotal_tva += $obj->_MONT;
							$obj->_SENS = 'C'; // Sens montant
							$obj->_LETT = ''; // Ref. pointage / lettrage
							$obj->_ANAL = ''; // Code analytique
							//$obj->_MTVA = $montant_tva; // Montant TVA
							$obj->_TTVA = $detail['tax_rate']; // Taux de TVA
							$obj->_CTVA = $this->GetCodeTva($detail['tax_name']); // Code TVA

							//if ( $obj->_MONT != 0.00 )
							//{
								$total_credit += $obj->_MONT;
								$this->ximportslist[] = $obj;
							//}
						}
					} // foreach ($this->vatlist as $vatlistline)

					// remise globale
					if ( floatval($detail['reduction_percent']) != 0.00 ) 
					{
						$obj = new Struct_XImport();
						$obj->_MVTS = $mvts;
						$obj->_ID = $order['id_order'];
						$obj->_JOUR = 'VT'; // Code journal
						$obj->_DECR = $order['date_add']; // Date écriture
						$obj->_DECH = $order['date_add']; // Date échéance
						$obj->_NUMP = $order['reference']; // N° de pièce
						$obj->_COMP = '451540'; // N° de compte
						$obj->_LIBE = $order['lastname']; // Libellé écriture
						//$montant_tva = $saleline->item_tax * $saleline->quantity;
						$tva = ($total_htva * $tax_rate->rate) / 100;
						$obj->_MONT = $this->roundMoney($tva,0.01); // Montant
						$gtotal_tva -= $obj->_MONT;
						if ( $saleslist_cnt == $current_cnt )
							// on est a la toute dernière ligne, on check si difference d'arrondi
						{
							$total_calcule = $gtotal_htva + $gtotal_tva;
							$val = floatval($header->grand_total);
							// https://stackoverflow.com/questions/3148937/compare-floats-in-php
							// if (abs(($total_calcule - $val)/ $val) < 0.00001)
							if ( abs($total_calcule - $val) < PHP_FLOAT_EPSILON )
								// difference d'arrondi, on met sur la dernière ligne de tva
							{
								$total_arrondi = $obj->_MONT + ($val - $total_calcule);
								$obj->_MONT = $this->roundMoney($total_arrondi,0.01);
							}
						}
						$obj->_SENS = 'D'; // Sens montant
						$obj->_LETT = ''; // Ref. pointage / lettrage
						$obj->_ANAL = ''; // Code analytique
						$obj->_MTVA = $montant_tva; // Montant TVA
						$obj->_TTVA = $detail['tax_rate']; // Taux de TVA
						$obj->_CTVA = $this->GetCodeTva($detail['tax_name']); // Code TVA

						if ( $obj->_MONT != 0.00 ) 
						{
							$total_debit += $obj->_MONT;
							$this->ximportslist[] = $obj;
						}
					}
					$current_cnt++;

					// on exporte ximport vers picsoo
					if ( $this->roundMoney($total_debit,0.01) != $this->roundMoney($total_credit,0.01) && $this->toexcel == true )
						// uniquement si excel est sélectionné par économie de mémoire
					{
						$bo = new Struct_BadTrans();
						$bo->_MVTS = $mvts;
						$bo->_ID = $saleid;
						$bo->_DEBIT = $total_debit;
						$bo->_CREDIT = $total_credit;
						$xbadtrans[] = $bo;
					}

					//$mvts++;
				} // foreach ( $details as $detail )
				$mvts++;
			} // if( $cnt > 0 )
		}
			//return; //DBG

		// ==============================================================================================================================================
		// dump vers excel ==============================================================================================================================
		// ==============================================================================================================================================
		if ( $this->toexcel == true ) 
		{
			$tot_DC = 0.00;
			$tot_TOTAL = 0.00;
			$tot_MontTVA = 0.00;
			$tot_TVA_0 = 0.00;
			$tot_TVA_6 = 0.00;
			$tot_TVA_12 = 0.00;
			$tot_TVA_21 = 0.00;
			$tot_TVA_inco = 0.00;
			$tot_TVA_hcee = 0.00;
			$tot_TVA_autre = 0.00;

			// C:\xampp\htdocs\prestashop\project\modules\exportproducts\controllers\admin\AdminExportProducts.php

			$delimiter = ';'; //Tools::getValue('export_delimiter');
			$id_shop = (int)$this->context->shop->id;

			set_time_limit(0);
			//$fileName = 'transactions_' . date("Y_m_d_H_i_s") . '.csv';
			
			//header("Content-Type: application/csv");
			//header("Content-Disposition: attachment; filename={$fileName}");				
			
			//header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			//header('Content-Description: File Transfer');
			//header("Content-type: text/csv");
			//header("Content-Disposition: attachment; filename={$fileName}");
			//header("Expires: 0");
			//header("Pragma: public");
			//echo "\xEF\xBB\xBF";

			$fp = fopen( 'php://output', 'w' );
			// Start output buffering (to capture stream contents)
			ob_clean();
			ob_start();

			$titles[] = 'MVTS';
			$titles[] = 'ID (PrestaS)';

			$titles[] = 'JOUR';
			$titles[] = 'DECR';
			$titles[] = 'DECH';
			$titles[] = 'NUMP';
			$titles[] = 'COMP';
			$titles[] = 'LIBE';
			$titles[] = 'MONT';
			$titles[] = 'SENS';
			$titles[] = 'MONT SIGNE';
			$titles[] = 'LETT';
			$titles[] = 'ANAL';
			$titles[] = 'MVTA';
			$titles[] = 'TTVA';
			$titles[] = 'CTVA';

			// données TVA
			$titles[] = 'TOTAL';
			$titles[] = 'Mont.TVA';
			$titles[] = '0';
			$titles[] = '6';
			$titles[] = '12';
			$titles[] = '21';
			$titles[] = 'inco';
			$titles[] = 'hcee';
			$titles[] = 'autre';

			fputcsv( $fp, $titles, $delimiter, '"' );
			$titles = array();

			$row = 2;
			foreach ($this->ximportslist as $ximport_line) 
			{
				// données ximport
				//$dbg1 = $ximport_line->_DECR;
				//$dbg2 = strtotime($ximport_line->_DECR);
				//$dbg3 = date('d/m/Y',$ximport_line->_DECR);
				//$dbg4 = date('d/m/Y',$ximport_line->_DECR);
				//$dbg5 = new DateTime($ximport_line->_DECR);
				//$dbg6 = $dbg5->format('Y-m-d H:i:s');
				//$delivery = $this->sales_model->getDeliveryByID($id);
				$line[] = $ximport_line->_MVTS;
				$line[] = $ximport_line->_ID;
				$line[] = $ximport_line->_JOUR;
				$line[] = strtok($ximport_line->_DECR,' ');
				$line[] = strtok($ximport_line->_DECH,' ');
				$line[] = $ximport_line->_NUMP;
				$line[] = $ximport_line->_COMP;
				$line[] = $ximport_line->_LIBE;
				$line[] = $ximport_line->_MONT;
				$line[] = $ximport_line->_SENS;
				if ( $ximport_line->_SENS == 'D' )
					$mnt = $ximport_line->_MONT;
				else
					$mnt = $ximport_line->_MONT * (-1);
				$tot_DC += $mnt;
				$line[] = $mnt;
				$line[] = $ximport_line->_LETT;
				$line[] = $ximport_line->_ANAL;
				$line[] = $ximport_line->_MTVA;
				$line[] = $ximport_line->_TTVA;
				$line[] = $ximport_line->_CTVA;

				// données TVA -------------------------------------------------------------------------------------------------------------------------
				if ( substr($ximport_line->_COMP, 0, 3) == '400') 
				{
					$line[] = $ximport_line->_MONT;
					$tot_TOTAL += $ximport_line->_MONT;
				} 
				else
					$line[] = '';

				if ( substr($ximport_line->_COMP, 0, 3) == '451') 
				{
					if ( $ximport_line->_SENS == 'C' ) {
						$line[] = $ximport_line->_MONT;
						$tot_MontTVA += $ximport_line->_MONT;
					}
					else
					{
						$line[] = ($ximport_line->_MONT * -1);
						$tot_MontTVA -= $ximport_line->_MONT;
					}
				}
				else
					$line[] = '';

				if ( substr($ximport_line->_COMP, 0, 1) == '7') 
				{
					if ( strpos($ximport_line->_CTVA, "0%") !== false ) 
					{
						if ( $ximport_line->_SENS == 'C' ) 
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_0 += $ximport_line->_MONT;
						} 
						else 
						{
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_0 -= $ximport_line->_MONT;
						}
					}
					else if ( strpos($ximport_line->_CTVA, "6%") !== false )
					{
						$line[] = '';
						if ( $ximport_line->_SENS == 'C' )
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_6 += $ximport_line->_MONT;
						}
						else
						{
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_6 -= $ximport_line->_MONT;
						}
					}
					else if ( strpos($ximport_line->_CTVA, "12%") !== false )
					{
						$line[] = '';
						$line[] = '';
						if ( $ximport_line->_SENS == 'C' )
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_12 += $ximport_line->_MONT;
						}
						else
						{
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_12 -= $ximport_line->_MONT;
						}
					}
					else if ( strpos($ximport_line->_CTVA, "21%") !== false )
					{
						$line[] = '';
						$line[] = '';
						$line[] = '';
						if ( $ximport_line->_SENS == 'C' )
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_21 += $ximport_line->_MONT;
						}
						else
						{
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_21 -= $ximport_line->_MONT;
						}
					}
					else if ( strpos($ximport_line->_CTVA, "INCO") !== false )
					{
						$line[] = '';
						$line[] = '';
						$line[] = '';
						$line[] = '';
						if ( $ximport_line->_SENS == 'C' )
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_inco += $ximport_line->_MONT;
						}
						else
						{
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_inco -= $ximport_line->_MONT;
						}
					}
					else if ( strpos($ximport_line->_CTVA, "HCEE") !== false )
					{
						$line[] = '';
						$line[] = '';
						$line[] = '';
						$line[] = '';
						$line[] = '';
						if ( $ximport_line->_SENS == 'C' )
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_hcee += $ximport_line->_MONT;
						}
						else
						{
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_hcee -= $ximport_line->_MONT;
						}
					}
					else
					{
						$line[] = '';
						$line[] = '';
						$line[] = '';
						$line[] = '';
						$line[] = '';
						$line[] = '';
						if ( $ximport_line->_SENS == 'C' )
						{
							$line[] = $ximport_line->_MONT;
							$tot_TVA_autre += $ximport_line->_MONT;
						} else {
							$line[] = ($ximport_line->_MONT * -1);
							$tot_TVA_autre -= $ximport_line->_MONT;
						}
					}
				} // if ( substr($ximport_line->_COMP, 0, 1) == '7')
				else
				{
					//$line[] = 'P' . $row, '');
					//$line[] = 'Q' . $row, '');
					//$line[] = 'R' . $row, '');
					//$line[] = 'S' . $row, '');
					//$line[] = 'T' . $row, '');
					//$line[] = 'U' . $row, '');
					//$line[] = 'V' . $row, '');
					//$line[] = 'W' . $row, '');
				}

				fputcsv( $fp, $line, $delimiter, '"' );
				$line = array();
				$row++;
			}
			// totaux en bas de page
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = 'TOTAL GENERAL >>';
			$line[] = $tot_DC;
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = '';
			$line[] = 'TOTAUX TVA >>';
			//fputcsv( $fp, $line, $delimiter, '"' );
			//$line = array();

			// données TVA
			$line[] = $tot_TOTAL;
			$line[] = $tot_MontTVA;
			$line[] = $tot_TVA_0;
			$line[] = $tot_TVA_6;
			$line[] = $tot_TVA_12;
			$line[] = $tot_TVA_21;
			$line[] = $tot_TVA_inco;
			$line[] = $tot_TVA_hcee;
			$line[] = $tot_TVA_autre;
			fputcsv( $fp, $line, $delimiter, '"' );
			$line = array();

			$row++;
			$arrLength = count($xbadtrans);
			if ( $arrLength > 0 ) {
				$total_debit = 0.00;
				$total_credit = 0.00;
				$line[] = 'MVTS';
				$line[] = 'ID (PrestaS)';
				$line[] = 'DEBIT';
				$line[] = 'CREDIT';
				fputcsv( $fp, $line, $delimiter, '"' );
				$line = array();
				$row++;
				foreach ($xbadtrans  as $xbadtrans_line) {
					$line[] = $xbadtrans_line->_MVTS;
					$line[] = $xbadtrans_line->_ID;
					$line[] = $xbadtrans_line->_DEBIT;
					$line[] = $xbadtrans_line->_CREDIT;
					$total_debit += $xbadtrans_line->_DEBIT;
					$total_credit += $xbadtrans_line->_CREDIT;
					fputcsv( $fp, $line, $delimiter, '"' );
					$line = array();
					$row++;
				}
				$line[] = '';
				$line[] = '';
				$line[] = $total_debit;
				$line[] = $total_credit;
				$line[] = $total_debit - $total_credit;
				fputcsv( $fp, $line, $delimiter, '"' );
				$line = array();
			}

			$row--;

			//continue;
			//fclose($fp);
			//exit;
			
			// Get the contents of the output buffer
			$csv = ob_get_clean();

			// Set the filename of the download
			$fileName = 'transactions_PRESTA_' . date("Y_m_d_H_i_s") . '.csv';

			// Output CSV-specific headers
			header('Content-Description: File Transfer');
			//header('Content-Type: application/octet-stream');
			header('Content-Type: application/vnd.ms-excel;');
			header('Content-Type: application/x-msexcel;');
			header("Content-Disposition: attachment; filename={$fileName}");
			header('Content-Transfer-Encoding: binary');
			header('Expires: 0');
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Pragma: public');

			$csv = chr(255) . chr(254) . iconv('UTF-8', 'UTF-16LE', $csv);

			exit($csv);
			
			return;
		} // dump vers Excel

		// ==============================================================================================================================================
		// dump vers Picsoo web =========================================================================================================================
		// ==============================================================================================================================================
		//				Net		Amount	DebitCreditType
		// client 400	+		+		D
		// 7...			+		-		C
		// TVA 45..		+		-		C
		
		$recordcount = 0; //DBG
		$CleMvt = 1;
		$myList = array();
		$CurrentMvt = $this->ximportslist[0]->_MVTS;
		$this->ErrNumber = 0;
		$r_e = '';
		//$myfile = fopen("dbg.txt", "w") or die("Unable to open file!"); // DBG

		foreach ($this->ximportslist as $ximport_line) 
		{
			/*if( $ximport_line->_MVTS != 177 ) //DBG
			{
			$CurrentMvt = $ximport_line->_MVTS;
			continue;
			}*/

			if ( $CurrentMvt != $ximport_line->_MVTS ) 
			{
				//fwrite($myfile, $myList); //DBG
				//if( $CurrentMvt==2 ) //DBG
				$result = $this->objPicsooWS->SaveTransactionsDetails($this->ie_clientsid, $myList, $r_e, $CurrentMvt);
				if ( $result['IsSuccess'] != true /*&& $result['IsSuccess']!=''*/ )
				{
					$this->genmsg = $result['Message'];
					//$this->session->set_flashdata('error', $msg );
					$logtype = 'error';

					$this->ErrNumber++;
				}

				if ( $result['IsSuccess'] == false ) {
					if ( $result['Message'] == 'Authcode Expired' ) {
						//$msg = $this->lang('export_finished') . ' - ' . $this->lang('try_later') . ' (AE).';
						//$this->session->set_flashdata('error', $msg );
						$logtype = 'error';
						//$this->log_message($logtype, 'Export transactions to Picsoo aborted (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
						return;
					} else if ( $result['Message'] == 'Data already exist.' ) {
						//$msg = $this->lang('export_finished') . ' - ' . $this->lang('data_already_exist');
						//$this->session->set_flashdata('error', $msg );
						$logtype = 'error';
						//$this->log_message($logtype, 'Export transactions to Picsoo aborted (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
						return;
					} else {
						//$msg = $this->lang('export_finished') . ' - ' . $result['Message'];
						//$this->session->set_flashdata('error', $msg );
						$logtype = 'error';
						//$this->log_message($logtype, 'Export transactions to Picsoo aborted (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );
						return;
					}
				}

				$CurrentMvt = $ximport_line->_MVTS;
				$myList = array();
			}

			$ty = '2'; //$this->GetTypeJournal( $ximport_line->_MVTS );
			$transtype = '';
			switch ($ty) {
				case '1':
					$transtype = 'Purchase'; //"ACHATS";
					break;
				case '5':
					$transtype = 'Purchase'; //"CRACHATS";
					break;
				case '2':
					$transtype = 'Sale'; //"VENTES";
					break;
				case '6':
					$transtype = 'Sale'; //"CRVENTES";
					break;
				case '4':
					$transtype = 'Bank'; //"FINANCIERS";
					break;
				case '3':
					$transtype = 'Journal'; //"OD";
					break;
				default:
					$transtype = 'Journal';
					break;
			}

			$debit = 0.00;
			$credit = 0.00;
			$sens_montant = '';
			if ($ximport_line->_SENS == 'D') 
			{
				$net = round($ximport_line->_MONT,2);
				$amount = round($ximport_line->_MONT,2);
				$sens_montant = 'Debit';
			} 
			else 
			{
				$net = round($ximport_line->_MONT,2);
				$amount = round(($ximport_line->_MONT * -1),2);
				$sens_montant = 'Credit';
			}

			$dt = substr( $ximport_line->_DECR, 0, 10); //new DateTime( $ximport_line->_DECR );
			$r_e = $this->reference_external . '_' . $dt /*->format('Y-m-d')*/ . '_' . $ximport_line->_NUMP;

			$datatosend = [
				'TransactionsId'			=> '0',
				'ClientsId'					=> $this->ie_clientsid,
				'FinancialPeriodId'			=> '',
				'AaccountNameId'			=> '',
				'CustomersId'				=> '',
				'EntityName'				=> $ximport_line->_LIBE,
				'TransactionCode'			=> $ximport_line->_NUMP,
				'TransactionType'			=> '', // ACHATS - VENTES - FINANCIERS - OD - CRACHATS - CRVENTES
				'JournalType'				=> $transtype,
				// transaction type (philippe 27/11/2019 @ 10:30) :
				// journal vente et crédit : Sale
				// achats et crédit : Purchase
				// OD : Journal
				// BQ : Cash
				// caisse : Cash
				'ReferenceId'				=> '',
				'TransactionDate'			=> $ximport_line->_DECR,
				'Description'				=> $ximport_line->_LIBE,
				'VateRate'					=> 0.00, // ??????????????????????????????????????????,
				'Net'						=> $net,
				'Amount'					=> $amount,
				'DebitCreditType'			=> $sens_montant,
				'IsDeleted'					=> 'false',
				'ModifiedDate'				=> $ximport_line->_DECR,
				'BackupId'					=> '',
				'ReverseReferance'			=> '',
				'ReverseTransactions'		=> '',
				'MasterBranchCategoryId1'	=> '',
				'MasterBranchCategoryId2'	=> '',
				'CreatedDate'				=> '',
				'ModifiedBy'				=> '',
				'CreatedBy'					=> '',
				'VATPercent'				=> $ximport_line->_TVAT,
				'VatCode'					=> $ximport_line->_CTVA,
				'GVat'						=> $ximport_line->_GTVA,
				'AccountGridType'			=> '', //$ximport_line->_GBAS,
				'VATTypeId'					=> '',
				'AccountName'				=> '',
				'CustomerCode'				=> '', //$ximport_line->_COMP28150,
				'InvoiceJournalCode'		=> $ximport_line->_JOUR,
				'BillSerivesGoodsId'		=> '',
				'JournalNumber'				=> $ximport_line->_NUMP,
				'VatPeriodId'				=> '',
				'Reference'					=> '',
				'DueDate'					=> '',
				'CurrencyRate'				=> '',
				'Currency'					=> '',
				'AmountCurrency'			=> '',
				'ProjectId'					=> '',
				'VatPeriod'					=> '',
				'Item'						=> '',
				'Qty'						=> '',
				'UnitPrice'					=> '',
				'Discount'					=> '',
				'ServicesGoods'				=> '',
				'vatNumber'					=> '',
				'EuropeanVatNumber'			=> '',
				'Employee'					=> '',
				'AccountCode'				=> $ximport_line->_COMP,
				'Flag'						=> '',
				'FlagDate'					=> '',
				'FlagUser'					=> '',
				'ExportFrom'				=> '',
				'TrackingNumber'			=> '',
				'BankDescription'			=> '',
				'BankRef'					=> '',
				'AccountGridType2'			=> '',
				'CreatedByName'				=> 'POS',
				'ModifiedByName'			=> 'POS',
				'Analyt'					=> 'ANALYT',
				'reference_external'		=> $r_e,  //$this->ie_reference . '_' .$ximport_line->_MVTS,
				'JournalType'				=> '',
				'TransactionCodeExternal'	=> '',
				'TransactionTypeExternal'	=> '',
				'ReconciliationCode'		=> '',

				'ReconciliationStatus'		=> '', // "Y" = reconcilié si LETT<>""; "N" = non reconcilié; "P" réconcilié partiellement
				'ReconciliationDate'		=> '',
				'ReconcilationId'			=> '',

				'ReminderLevel'				=> '',

				'VatCode'					=> $ximport_line->_CTVA,
				'VATPercent'				=> $ximport_line->_TVAT,
				'AccountGridType'			=> $ximport_line->_GBAS,
				'GVat'						=> $ximport_line->_GTVA,
			];

			$myList[] = $datatosend;
			$recordcount++;
		}

		$result = $this->objPicsooWS->SaveTransactionsDetails($this->ie_clientsid, $myList, $r_e, $CurrentMvt); // le dernier
		if ( $result['IsSuccess'] != true /*&& $result['IsSuccess']!=''*/ )
		{
			$this->genmsg = $result['Message'];
			//$this->session->set_flashdata('error', $msg );
			$logtype = 'error';
			$this->ErrNumber++;
		}

		// ==============================================================================================================================================
		// ==============================================================================================================================================
		// ==============================================================================================================================================

		//fclose($myfile);

		//if( $CurrentMvt==2 ) //DBG
		$msg = $this->lang('export_finished');
		if ( $this->ErrNumber != 0 ) {
			//$msg .= ' (' . $this->lang('errors_detected') . ' - ' . $this->ErrNumber . ' )';
			//$this->session->set_flashdata('error', $msg );
			$logtype = 'error';
		} else {
			//$msg .= $this->lang('awaiting_email');
			//$this->session->set_flashdata('message', $msg );
			$logtype = 'info';
		}

		//$this->log_message($logtype, 'Export transactions to Picsoo (' . $this->ie_clientsid . ') - msg : ' . $result['Message'] . ' - ' . $result['Data'] );

		return $err;
	}

	private function GetTypeJournal( $_jour = '' )
	{
		$ret = '-1';

		return $ret;
	}
	
	private function GetCodeTva( $_codetvapresta )
	{
		if (strpos($_codetvapresta, '0%') !== false)
			return '0';
		if (strpos($_codetvapresta, '6%') !== false)
			return '6';
		if (strpos($_codetvapresta, '12%') !== false)
			return '12';
		if (strpos($_codetvapresta, '21%') !== false)
			return '21';
		if (strpos($_codetvapresta, 'INCO') !== false)
			return 'INCO';
		if (strpos($_codetvapresta, 'HCEE') !== false)
			return 'HCEE';
		
			return '';
	}
	
	// --------------------------------------------------------------------------------------------------------------------------------
	// on ne retient dans vat list que ce qui concerne les ventes
	// --------------------------------------------------------------------------------------------------------------------------------
	private function CleanVatList()
    {
		foreach ($this->vatlist as $key => $value)
		{

			if ($value['Type'] != 'P')
			{

				unset($this->vatlist[$key]);
			}
		}
		Sort($this->vatlist);
		$cnt = count($this->vatlist);
		return;
    }
	
	// ===========================================================================================================================================================
	//
	// ===========================================================================================================================================================

	private function add_customers($xcustomer)
	{
		$user_password = '12345';
		
		$existing_customer = new Customer();
		$is_exist = $existing_customer->customerExists(strtolower(trim($xcustomer['email'])));

		if (!$is_exist)
		{
			// créer l'utilisateur
			try
			{				
				$customer = new Customer();
				$customer->company = trim($xcustomer['company']);
				$customer->lastname = trim($xcustomer['lastname']);
				$customer->firstname = trim($xcustomer['firstname']);
				if( trim($xcustomer['title'])=='M' )
					$customer->id_gender = 1;
				else if( trim($xcustomer['title'])=='Mme' )
					$customer->id_gender = 2;
				else
					$customer->id_gender = 0;
					
				$customer->passwd = md5(pSQL(_COOKIE_KEY_ . $user_password));
				if (!Validate::isEmail(trim($xcustomer['email']))) 
					$customer->email = '';
				else
					$customer->email = strtolower(trim($xcustomer['email']));
				$customer->siret = trim($xcustomer['vat_no']);
				$customer->is_guest = 0;
				$customer->active = 1;

				if ($customer->add())
				{
					try
					{
						// creation adresse
						$address = new Address();
						$address->id_customer = (int)$customer->id;
						$address->id_country = 8;
						$address->alias = 'Mon adresse';
						$address->lastname = $customer->lastname;
						$address->firstname = $customer->firstname;
						$address->address1 = $this->objPicsooWS->RemoveSpecialChar(trim($xcustomer['address']));
						$address->postcode = trim($xcustomer['postal_code']);
						$address->phone = trim($xcustomer['phone']);
						$address->city = trim($xcustomer['city']);
						$address->add();
					}
					catch (Exception $e) 
					{
    					//echo 'Caught exception: ',  $e->getMessage(), "\n";
    					return false;
					}
				}
			}
			catch (Exception $e) 
			{
    			//echo 'Caught exception: ',  $e->getMessage(), "\n";
    			return false;
			}
		}
		
		return true;
	}
	
	private function lang( $_text )
	{
		return $_text;		
	}
	
	private function log_message($logtype, $msg )
	{
		
		return;
	}

	private function roundMoney($num, $nearest = 0.05)
	{
		return round($num * (1 / $nearest)) * $nearest;
	}
} // class Picsoo extends Module 
